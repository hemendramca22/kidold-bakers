import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/features/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          chocolate: {
            DEFAULT: "#2C1810",
            light: "#4A2E1B",
            dark: "#1A0D08",
          },
          crimson: {
            DEFAULT: "#8B1528",
            light: "#A82035",
            hover: "#700F1E",
            dark: "#590916",
          },
          gold: {
            DEFAULT: "#C89D3C",
            light: "#E5B958",
            sparkle: "#F5C542",
            muted: "#DFD3B6",
          },
          cream: {
            DEFAULT: "#FFFDF7",
            warm: "#FBF5EB",
            biscuit: "#F3E9DC",
          },
          apricot: {
            DEFAULT: "#E67E22",
            light: "#F39C12",
          },
          surface: {
            DEFAULT: "#FFFFFF",
            warm: "#FAF7F2",
          },
          border: {
            DEFAULT: "#EADBCC",
            subtle: "#F5ECE2",
          },
        },
      },
      fontFamily: {
        serif: ["var(--font-playfair)", "Georgia", "serif"],
        sans: ["var(--font-jakarta)", "system-ui", "-apple-system", "sans-serif"],
      },
      boxShadow: {
        bakery: "0 4px 20px -2px rgba(44, 24, 16, 0.08)",
        "bakery-md": "0 8px 24px -3px rgba(44, 24, 16, 0.10)",
        "bakery-lg": "0 16px 36px -4px rgba(44, 24, 16, 0.14)",
        crimson: "0 4px 18px -2px rgba(139, 21, 40, 0.28)",
        gold: "0 4px 18px -2px rgba(200, 157, 60, 0.30)",
        // Tactile & Dimensional Shadows (Priority 4 Polish)
        "tactile-sm": "inset 0 1px 0 rgba(255, 255, 255, 0.7), 0 2px 8px -1px rgba(44, 24, 16, 0.06)",
        tactile: "inset 0 1px 0 rgba(255, 255, 255, 0.8), 0 6px 20px -2px rgba(44, 24, 16, 0.08), 0 2px 4px rgba(44, 24, 16, 0.04)",
        "tactile-hover": "inset 0 1px 0 rgba(255, 255, 255, 0.9), 0 16px 36px -4px rgba(44, 24, 16, 0.14), 0 4px 8px rgba(44, 24, 16, 0.06)",
        "tactile-pressed": "inset 0 3px 6px rgba(44, 24, 16, 0.2), 0 1px 2px rgba(44, 24, 16, 0.08)",
        "crimson-tactile": "inset 0 1px 0 rgba(255, 255, 255, 0.28), 0 6px 18px -2px rgba(139, 21, 40, 0.35)",
        "gold-tactile": "inset 0 1px 0 rgba(255, 255, 255, 0.45), 0 6px 18px -2px rgba(200, 157, 60, 0.35)",
        "chocolate-tactile": "inset 0 1px 0 rgba(255, 255, 255, 0.15), 0 6px 18px -2px rgba(44, 24, 16, 0.28)",
      },
      borderRadius: {
        "4xl": "2rem",
      },
    },
  },
  plugins: [],
};

export default config;
