"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Container } from "@/components/ui/Container";
import { Button } from "@/components/ui/Button";
import { WhatsAppIcon, SparklesIcon } from "@/components/icons";
import { getWhatsAppInquiryUrl } from "@/lib/whatsapp";
import { MobileNav } from "./MobileNav";

const NAV_LINKS = [
  { name: "Signature Cakes", href: "#signature-cakes" },
  { name: "Categories", href: "#categories" },
  { name: "Design My Cake", href: "#custom-cakes" },
  { name: "Our Story", href: "#our-story" },
  { name: "Visit Us", href: "#visit-us" },
];

export function Navbar() {
  const pathname = usePathname();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isOverDark, setIsOverDark] = useState(false);
  const [activeSection, setActiveSection] = useState<string>("");
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const headerRef = useRef<HTMLElement>(null);
  const pillRef = useRef<HTMLDivElement>(null);

  const isLinkActive = useCallback(
    (href: string) => {
      const sectionId = href.split("#")[1] || "";
      if (pathname === "/design-my-cake") {
        return sectionId === "custom-cakes";
      }
      return activeSection === sectionId;
    },
    [pathname, activeSection]
  );

  const navLinks = NAV_LINKS.map((link) => ({
    ...link,
    href: pathname === "/" ? link.href : `/${link.href}`,
  }));

  useEffect(() => {
    let ticking = false;

    const updateNavbarContrast = () => {
      const scrollY = window.scrollY;
      const scrolled = scrollY > 20;
      setIsScrolled(scrolled);

      // Track active section for anchored nav links
      if (pathname === "/design-my-cake") {
        setActiveSection("custom-cakes");
      } else {
        const domSectionIds = [
          "categories",
          "signature-cakes",
          "custom-cakes",
          "our-story",
          "visit-us",
        ];
        let current = "";

        if (
          window.innerHeight + scrollY >=
          document.documentElement.scrollHeight - 80
        ) {
          current = "visit-us";
        } else if (scrollY > 150) {
          for (const id of domSectionIds) {
            const el = document.getElementById(id);
            if (el) {
              const r = el.getBoundingClientRect();
              if (r.top <= 260 && r.bottom >= 120) {
                current = id;
                break;
              }
            }
          }
        }
        setActiveSection(current);
      }

      if (!headerRef.current || !pillRef.current) return;

      if (!scrolled) {
        setIsOverDark(false);
        return;
      }

      const pillRect = pillRef.current.getBoundingClientRect();

      // Find all imagery, product photos, dark sections, and footer candidates
      const candidateElements = document.querySelectorAll<HTMLElement>(
        'img, picture, footer, [data-contrast="dark"], [data-dark="true"]'
      );

      let darkUnderneath = false;

      for (let i = 0; i < candidateElements.length; i++) {
        const el = candidateElements[i];
        // Skip the navbar's own logo
        if (headerRef.current.contains(el)) continue;

        const r = el.getBoundingClientRect();
        // Check if element is active, visible, and overlaps vertically & horizontally with navbar pill
        if (r.width > 24 && r.height > 24 && r.bottom > 0 && r.top < window.innerHeight) {
          // Generous 20px vertical buffer so transition anticipates dark imagery smoothly
          const verticalOverlap = r.top < pillRect.bottom + 20 && r.bottom > pillRect.top - 20;
          const horizontalOverlap = r.left < pillRect.right && r.right > pillRect.left;

          if (verticalOverlap && horizontalOverlap) {
            darkUnderneath = true;
            break;
          }
        }
      }

      setIsOverDark(darkUnderneath);
    };

    const onScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          updateNavbarContrast();
          ticking = false;
        });
        ticking = true;
      }
    };

    updateNavbarContrast();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });

    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [pathname]);

  return (
    <>
      <header
        ref={headerRef}
        className="sticky top-0 z-40 transition-all duration-300 px-3 sm:px-6 pt-2 sm:pt-3"
      >
        <div
          ref={pillRef}
          style={{
            backgroundColor: !isScrolled
              ? "rgba(250, 245, 237, 0.75)"
              : isOverDark
              ? "rgba(249, 243, 233, 0.84)"
              : "rgba(255, 253, 249, 0.80)",
          }}
          className={`mx-auto relative transition-all duration-300 ease-out ${
            !isScrolled
              ? "max-w-7xl rounded-2xl sm:rounded-full backdrop-blur-lg backdrop-saturate-[1.2] border border-[#D4AF37]/30 shadow-[0_8px_30px_rgba(44,24,16,0.06),0_1.5px_4px_rgba(44,24,16,0.03),inset_0_1.5px_1px_rgba(255,255,255,0.85),inset_0_-1px_1px_rgba(216,170,66,0.12)] px-4 sm:px-6 py-3"
              : isOverDark
              ? "max-w-6xl rounded-full backdrop-blur-2xl backdrop-saturate-[1.45] border border-[#D4AF37]/55 shadow-[0_12px_40px_rgba(44,24,16,0.12),0_2px_6px_rgba(44,24,16,0.05),inset_0_1.5px_1px_rgba(255,255,255,0.9),inset_0_-1px_1px_rgba(216,170,66,0.18)] px-4 sm:px-6 py-2.5"
              : "max-w-6xl rounded-full backdrop-blur-xl backdrop-saturate-[1.25] border border-[#D4AF37]/40 shadow-[0_10px_35px_rgba(44,24,16,0.08),0_2px_5px_rgba(44,24,16,0.03),inset_0_1.5px_1px_rgba(255,255,255,0.85),inset_0_-1px_1px_rgba(216,170,66,0.14)] px-4 sm:px-6 py-2.5"
          }`}
        >
          {/* Subtle Inner Ambient Light Layer for Frosted Glass Depth */}
          <div
            className={`absolute inset-0 rounded-2xl sm:rounded-full pointer-events-none transition-opacity duration-300 -z-10 ${
              isOverDark
                ? "opacity-60 bg-gradient-to-b from-white/45 via-transparent to-brand-gold/[0.05]"
                : isScrolled
                ? "opacity-50 bg-gradient-to-b from-white/35 via-transparent to-brand-gold/[0.03]"
                : "opacity-35 bg-gradient-to-b from-white/30 via-transparent to-transparent"
            }`}
            aria-hidden="true"
          />

          <div className="flex items-center justify-between">
            {/* Clean Brand Identity Logo & Wordmark */}
            <Link
              href="/"
              className="flex items-center gap-2.5 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold rounded-full p-0.5"
              aria-label="KidOld Bakers Home"
            >
              {/* Natural Scalloped Seal */}
              <div className="relative w-10 h-10 sm:w-11 sm:h-11 shrink-0 transition-transform duration-300 group-hover:scale-105 drop-shadow-sm">
                <Image
                  src="/images/brand/kidold-logo-clean.png"
                  alt="KidOld Bakers Logo"
                  fill
                  priority
                  sizes="48px"
                  className="object-contain"
                />
              </div>

              <div className="flex flex-col justify-center">
                <div className="flex items-center gap-1.5">
                  <span
                    className="font-extrabold text-lg sm:text-xl tracking-tight text-brand-chocolate-dark font-sans group-hover:text-brand-crimson transition-colors duration-300"
                    style={{
                      color: "#1A0D08",
                      textShadow: isOverDark
                        ? "0 1px 1.5px rgba(255, 255, 255, 0.95), 0 0 4px rgba(255, 250, 240, 0.8)"
                        : "0 1px 1px rgba(255, 255, 255, 0.6)",
                    }}
                  >
                    KidOld Bakers
                  </span>
                </div>
                <span
                  className="text-[10px] uppercase tracking-wider text-brand-chocolate-light font-bold -mt-0.5 hidden sm:inline-block transition-colors duration-300"
                  style={{
                    textShadow: isOverDark
                      ? "0 1px 1px rgba(255, 255, 255, 0.9)"
                      : "0 1px 1px rgba(255, 255, 255, 0.5)",
                  }}
                >
                  Jaunpur, Uttar Pradesh
                </span>
              </div>
            </Link>

            {/* Desktop Navigation Links with subtle frosted veil capsule & crisp dark chocolate text */}
            <nav
              className={`hidden xl:flex items-center gap-1 xl:gap-1.5 px-3 py-1 rounded-full transition-all duration-300 ${
                isOverDark
                  ? "bg-white/60 border border-white/80 shadow-[inset_0_1px_1px_rgba(255,255,255,0.95),0_2px_8px_rgba(44,24,16,0.06)] backdrop-blur-md"
                  : isScrolled
                  ? "bg-white/30 border border-white/50 shadow-[inset_0_1px_0.5px_rgba(255,255,255,0.8)]"
                  : "bg-transparent border border-transparent"
              }`}
              aria-label="Main Navigation"
            >
              {navLinks.map((link) => {
                const isActive = isLinkActive(link.href);
                return (
                  <a
                    key={link.name}
                    href={link.href}
                    onClick={() => setActiveSection(link.href.split("#")[1] || "")}
                    className={`text-xs xl:text-sm font-bold tracking-tight px-3.5 py-1.5 rounded-full border transition-all duration-200 cursor-pointer whitespace-nowrap ${
                      isActive
                        ? "bg-[#EBD8BE] border-[#C59B3F]/65 text-[#1A0D08] shadow-[inset_0_1px_1.5px_rgba(255,255,255,0.95),0_2px_5px_rgba(44,24,16,0.1)] hover:bg-[#E5D0B3]"
                        : "bg-transparent border-transparent text-[#1A0D08] hover:bg-[#F6EFE6] hover:border-[#D4AF37]/35 hover:shadow-[0_1px_3px_rgba(44,24,16,0.06),inset_0_1px_0_rgba(255,255,255,0.9)] active:scale-[0.97]"
                    }`}
                    style={{
                      color: "#1A0D08",
                      textShadow:
                        isOverDark && !isActive
                          ? "0 1px 1px rgba(255, 255, 255, 0.95), 0 0 2px rgba(255, 250, 240, 0.8)"
                          : "0 1px 0.5px rgba(255, 255, 255, 0.7)",
                    }}
                    aria-current={isActive ? "page" : undefined}
                  >
                    {link.name}
                  </a>
                );
              })}
            </nav>

            {/* Desktop Action CTAs with subtle skeuomorphic depth & tactile press */}
            <div className="hidden xl:flex items-center gap-2.5">
              <Button
                variant="whatsapp"
                size="sm"
                href={getWhatsAppInquiryUrl()}
                isExternal
                leftIcon={<WhatsAppIcon className="w-4 h-4 text-brand-gold" />}
                className={`text-xs border whitespace-nowrap transition-all duration-300 ${
                  isOverDark
                    ? "border-brand-gold/60 shadow-[0_3px_10px_rgba(44,24,16,0.26),inset_0_1px_0.5px_rgba(255,255,255,0.3)]"
                    : "border-brand-gold/40 shadow-[0_2px_6px_rgba(44,24,16,0.2),inset_0_1px_0.5px_rgba(255,255,255,0.25)]"
                } hover:shadow-[0_4px_14px_rgba(44,24,16,0.28),inset_0_1px_1px_rgba(255,255,255,0.35)] active:scale-[0.97] active:translate-y-[0.5px]`}
              >
                WhatsApp Order
              </Button>
              <Button
                variant="primary"
                size="sm"
                href="#custom-cakes"
                leftIcon={<SparklesIcon className="w-3.5 h-3.5" />}
                className={`text-xs border whitespace-nowrap transition-all duration-300 ${
                  isOverDark
                    ? "border-brand-gold/45 shadow-[0_3px_10px_rgba(139,21,40,0.32),inset_0_1px_0.5px_rgba(255,255,255,0.35)]"
                    : "border-brand-gold/30 shadow-[0_2px_8px_rgba(139,21,40,0.25),inset_0_1px_0.5px_rgba(255,255,255,0.3)]"
                } hover:shadow-[0_6px_18px_rgba(139,21,40,0.35),inset_0_1px_1px_rgba(255,255,255,0.4)] active:scale-[0.97] active:translate-y-[0.5px]`}
              >
                Design My Cake
              </Button>
            </div>

            {/* Compact / Mobile Controls */}
            <div className="flex items-center gap-2 xl:hidden">
              <Button
                variant="whatsapp"
                size="sm"
                href={getWhatsAppInquiryUrl()}
                isExternal
                className="px-2.5 min-h-[36px] active:scale-95 shadow-tactile-sm border border-brand-gold/30"
                aria-label="Order on WhatsApp"
              >
                <WhatsAppIcon className="w-4 h-4 text-brand-gold" />
              </Button>
              <button
                type="button"
                onClick={() => setIsMobileOpen(true)}
                className={`p-2 rounded-xl text-brand-chocolate active:scale-95 transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold ${
                  isOverDark
                    ? "bg-white/70 border border-brand-gold/40 hover:bg-white/90"
                    : "hover:bg-brand-cream-warm/80"
                }`}
                aria-label="Open Navigation Menu"
                aria-expanded={isMobileOpen}
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Slide-over Navigation */}
      <MobileNav
        isOpen={isMobileOpen}
        onClose={() => setIsMobileOpen(false)}
        navLinks={navLinks}
        activeSection={activeSection}
      />
    </>
  );
}
