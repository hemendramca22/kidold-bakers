﻿"use client";

import React, { useState, useEffect, useRef } from "react";
import { businessData } from "@/data/business";
import { getWhatsAppInquiryUrl } from "@/lib/whatsapp";
import { PhoneIcon, WhatsAppIcon, MapPinIcon } from "@/components/icons";

/**
 * Mobile-Only Sticky Customer Action Dock
 * Fixed near bottom-left with safe-area padding.
 * Primary action: Call (+91 93109 71535)
 * Secondary expandable: WhatsApp consultation & Google Maps Navigation.
 * Hidden on desktop (md:hidden).
 */
export function MobileActionDock() {
  const [isOpen, setIsOpen] = useState(false);
  const [isHeroVisible, setIsHeroVisible] = useState(true);
  const dockRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const hero = document.getElementById("hero");
    if (!hero) {
      setIsHeroVisible(false);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => setIsHeroVisible(entry.isIntersecting),
      { threshold: 0.08 }
    );
    observer.observe(hero);
    return () => observer.disconnect();
  }, []);

  // Close when clicking outside or pressing Escape
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dockRef.current && !dockRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen]);

  if (isHeroVisible) return null;

  return (
    <aside
      ref={dockRef}
      aria-label="Mobile Quick Contact Dock"
      className="pointer-events-none fixed bottom-4 left-4 z-40 md:hidden select-none pb-[env(safe-area-inset-bottom,0)]"
    >
      {/* Expanded Actions Tray (Slides Up) */}
      {isOpen && (
        <div
          role="menu"
          aria-label="Quick Actions"
          className="pointer-events-auto mb-2.5 p-2 rounded-2xl bg-[#FFFDF9]/95 backdrop-blur-md border border-brand-gold/50 shadow-[0_12px_32px_rgba(44,24,16,0.18)] flex flex-col gap-2 min-w-[210px] animate-in fade-in slide-in-from-bottom-2 duration-200"
        >
          {/* Action 1: WhatsApp */}
          <a
            role="menuitem"
            href={getWhatsAppInquiryUrl()}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setIsOpen(false)}
            className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-white/90 hover:bg-white border border-brand-border/60 text-brand-chocolate hover:text-brand-crimson transition-colors shadow-2xs text-xs font-bold"
          >
            <span className="w-7 h-7 rounded-full bg-brand-chocolate text-brand-gold flex items-center justify-center shrink-0 shadow-2xs">
              <WhatsAppIcon className="w-4 h-4 text-brand-gold" />
            </span>
            <div className="flex flex-col text-left">
              <span>Chat on WhatsApp</span>
              <span className="text-[10px] text-brand-chocolate-light font-normal">
                Direct Baker Consultation
              </span>
            </div>
          </a>

          {/* Action 2: Navigate to Shop */}
          <a
            role="menuitem"
            href={businessData.googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setIsOpen(false)}
            className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-white/90 hover:bg-white border border-brand-border/60 text-brand-chocolate hover:text-brand-crimson transition-colors shadow-2xs text-xs font-bold"
          >
            <span className="w-7 h-7 rounded-full bg-brand-crimson/10 text-brand-crimson flex items-center justify-center shrink-0 shadow-2xs">
              <MapPinIcon className="w-4 h-4 text-brand-crimson" />
            </span>
            <div className="flex flex-col text-left">
              <span>Directions / Shop</span>
              <span className="text-[10px] text-brand-chocolate-light font-normal">
                Line Bazaar, Jaunpur
              </span>
            </div>
          </a>
        </div>
      )}

      {/* Main Dock Bar */}
      <div className="pointer-events-auto flex items-center gap-1.5 p-1.5 rounded-full bg-[#FFFDF9]/95 backdrop-blur-md border border-brand-gold/50 shadow-[0_8px_24px_rgba(44,24,16,0.16)]">
        {/* Primary Action: Direct Phone Call */}
        <a
          href={`tel:${businessData.phoneRaw}`}
          className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-b from-[#A31D33] via-[#8B1528] to-[#6E0F1E] text-white shadow-crimson-tactile active:scale-95 transition-all border border-brand-gold/30"
          aria-label={`Call KidOld Bakers at ${businessData.phoneDisplay}`}
        >
          <PhoneIcon className="w-4 h-4 text-brand-gold-sparkle shrink-0" />
          <span className="sr-only">Call Bakery</span>
        </a>

        {/* Expandable Menu Toggle Button */}
        <button
          type="button"
          onClick={() => setIsOpen((prev) => !prev)}
          className={`w-9 h-9 rounded-full flex items-center justify-center transition-all border ${
            isOpen
              ? "bg-brand-chocolate text-brand-gold border-brand-gold rotate-180"
              : "bg-white text-brand-chocolate border-brand-border/80 hover:border-brand-gold shadow-2xs"
          }`}
          aria-expanded={isOpen}
          aria-label={isOpen ? "Close quick menu" : "Open quick contact menu"}
        >
          <svg
            className="w-4 h-4 transition-transform duration-200"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2.5"
              d="M5 15l7-7 7 7"
            />
          </svg>
        </button>
      </div>
    </aside>
  );
}
