import React from "react";
import { Container } from "@/components/ui/Container";
import { businessData } from "@/data/business";
import { SparklesIcon, HeartSparkleIcon } from "@/components/icons";

export function TrustBadges() {
  const getIcon = (type: string) => {
    switch (type) {
      case "fresh":
        return (
          <span className="w-10 h-10 rounded-full bg-brand-gold/15 text-brand-gold flex items-center justify-center shrink-0 shadow-tactile-sm">
            <SparklesIcon className="w-5 h-5 text-brand-gold" />
          </span>
        );
      case "eggless":
        return (
          <span className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 border border-emerald-200 shadow-tactile-sm">
            <span className="w-3 h-3 rounded-full bg-emerald-600 block" />
          </span>
        );
      case "handcrafted":
        return (
          <span className="w-10 h-10 rounded-full bg-brand-crimson/10 text-brand-crimson flex items-center justify-center shrink-0 shadow-tactile-sm">
            <HeartSparkleIcon className="w-5 h-5 text-brand-crimson" />
          </span>
        );
      default:
        return (
          <span className="w-10 h-10 rounded-full bg-brand-chocolate/10 text-brand-chocolate flex items-center justify-center shrink-0 shadow-tactile-sm">
            <SparklesIcon className="w-5 h-5 text-brand-chocolate" />
          </span>
        );
    }
  };

  return (
    <section className="py-8 bg-gradient-to-r from-brand-cream-warm via-brand-cream to-brand-cream-warm border-y border-brand-border/70">
      <Container>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {businessData.promises.map((promise) => (
            <div
              key={promise.id}
              className="flex items-start gap-3.5 p-4 rounded-2xl bg-white/85 backdrop-blur-xs border border-brand-border/80 shadow-tactile-sm hover:shadow-tactile hover:-translate-y-0.5 transition-all duration-200"
            >
              {getIcon(promise.icon)}
              <div>
                <h3 className="text-sm font-bold text-brand-chocolate font-sans">
                  {promise.title}
                </h3>
                <p className="mt-1 text-xs text-brand-chocolate/75 leading-relaxed">
                  {promise.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}
