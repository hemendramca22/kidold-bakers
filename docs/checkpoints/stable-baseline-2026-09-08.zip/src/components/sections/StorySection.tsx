"use client";

import React, { useRef, useEffect } from "react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Card } from "@/components/ui/Card";
import { SafeImage } from "@/components/ui/SafeImage";
import { HeartSparkleIcon, SparklesIcon, MapPinIcon } from "@/components/icons";
import { registerGSAP, shouldReduceMotion, animateHeadingReveal } from "@/lib/motion";

export function StorySection() {
  const sectionRef = useRef<HTMLElement>(null);
  const photoRef = useRef<HTMLDivElement>(null);
  const quoteRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const valuesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window === "undefined" || shouldReduceMotion()) return;

    const { gsap } = registerGSAP();
    const ctx = gsap.context(() => {
      // 1. Left Column: Editorial Photo Frame Entrance
      if (photoRef.current) {
        gsap.fromTo(
          photoRef.current,
          { opacity: 0, scale: 0.95, y: 32 },
          {
            opacity: 1,
            scale: 1,
            y: 0,
            duration: 0.85,
            ease: "power2.out",
            scrollTrigger: {
              trigger: sectionRef.current,
              start: "top 80%",
              toggleActions: "play none none none",
            },
          }
        );

        // Floating quote badge subtle entrance
        if (quoteRef.current) {
          gsap.fromTo(
            quoteRef.current,
            { opacity: 0, y: 15 },
            {
              opacity: 1,
              y: 0,
              duration: 0.6,
              delay: 0.3,
              ease: "power2.out",
              scrollTrigger: {
                trigger: sectionRef.current,
                start: "top 80%",
                toggleActions: "play none none none",
              },
            }
          );
        }

        // Desktop editorial magazine parallax
        if (window.innerWidth >= 768 && sectionRef.current) {
          gsap.fromTo(
            photoRef.current,
            { yPercent: 4 },
            {
              yPercent: -4,
              ease: "none",
              scrollTrigger: {
                trigger: sectionRef.current,
                start: "top bottom",
                end: "bottom top",
                scrub: 0.7,
              },
            }
          );
        }
      }

      // 2. Right Column: Masked Heading Reveal
      if (headingRef.current) {
        animateHeadingReveal(headingRef.current);
      }

      // 3. Narrative Paragraphs Reveal
      gsap.fromTo(
        ".story-paragraph",
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.15,
          ease: "power2.out",
          scrollTrigger: {
            trigger: headingRef.current,
            start: "top 75%",
            toggleActions: "play none none none",
          },
        }
      );

      // 4. Staggered Values Pillars Cascade
      if (valuesRef.current) {
        const valueCards = valuesRef.current.querySelectorAll(".story-value-card");
        gsap.fromTo(
          valueCards,
          { opacity: 0, y: 28 },
          {
            opacity: 1,
            y: 0,
            duration: 0.65,
            stagger: 0.12,
            ease: "power2.out",
            scrollTrigger: {
              trigger: valuesRef.current,
              start: "top 85%",
              toggleActions: "play none none none",
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="our-story"
      className="py-16 sm:py-24 bg-brand-cream-warm relative overflow-hidden"
    >
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column: Intergenerational Editorial Photography Frame */}
          <div className="lg:col-span-5 flex justify-center">
            <div
              ref={photoRef}
              className="relative w-full max-w-md aspect-[4/4.5] sm:aspect-square p-3 sm:p-4 rounded-3xl bg-gradient-to-b from-brand-gold/25 via-brand-cream to-brand-crimson/15 shadow-tactile-hover border-2 border-brand-gold/40 flex items-center justify-center overflow-hidden"
            >
              {/* Warm Intergenerational Photograph */}
              <div className="relative w-full h-full rounded-2xl overflow-hidden shadow-inner">
                <SafeImage
                  src="/images/story/story-generations.jpg"
                  alt="Indian grandfather and grandson sharing a warm celebration cake moment in Jaunpur, Uttar Pradesh"
                  fallbackLabel="KidOld Intergenerational Bakery Story"
                  fill
                  sizes="(max-width: 768px) 100vw, 450px"
                  className="object-cover transition-transform duration-700 hover:scale-105"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-brand-chocolate/40 via-transparent to-transparent pointer-events-none" />
              </div>

              {/* Floating Quote Badge */}
              <div
                ref={quoteRef}
                className="absolute bottom-5 bg-white/95 backdrop-blur-xs px-4 sm:px-5 py-2 rounded-full shadow-tactile border border-brand-gold/50 flex items-center gap-2 text-xs font-bold text-brand-chocolate pointer-events-none"
              >
                <HeartSparkleIcon className="w-4 h-4 text-brand-crimson shrink-0" />
                <span>Where Legacy Meets Indulgence</span>
              </div>
            </div>
          </div>

          {/* Right Column: Narrative & Values */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div ref={headingRef}>
              <SectionHeading
                badge="Our Story"
                title="Our Story: A Child's Wonder. A Grandparent's Warmth."
                subtitle="The story of KidOld Bakers begins with a simple truth: the purest joy is found when generations come together over something sweet."
                align="left"
              />
            </div>

            <div className="space-y-4 text-sm sm:text-base text-brand-chocolate/80 leading-relaxed font-sans">
              <p className="story-paragraph">
                Look closely at the soul of our bakery. It was born from the timeless companionship of a grandfather sharing his treasured treats with a wide-eyed grandson.
              </p>
              <p className="story-paragraph">
                That is the promise behind <strong>KidOld Bakers</strong> in Jaunpur. We bake to turn everyday tea-time conversations and milestone family birthdays into lifelong memories. Every recipe is crafted with honest, wholesome ingredients and patience.
              </p>
            </div>

            {/* Core Values Pillars */}
            <div ref={valuesRef} className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              <Card className="story-value-card p-5 bg-white border border-brand-border/80 shadow-tactile hover:shadow-tactile-hover flex flex-col justify-between min-h-[150px]">
                <div>
                  <div className="w-10 h-10 rounded-full bg-brand-crimson/10 text-brand-crimson flex items-center justify-center mb-3 shadow-tactile-sm">
                    <HeartSparkleIcon className="w-5 h-5" />
                  </div>
                  <h4 className="text-sm font-bold text-brand-chocolate font-sans">Family First</h4>
                  <p className="text-xs text-brand-chocolate/75 mt-1.5 leading-relaxed">
                    Recipes crafted to delight grandparents and toddlers equally across every generation.
                  </p>
                </div>
              </Card>

              <Card className="story-value-card p-5 bg-white border border-brand-border/80 shadow-tactile hover:shadow-tactile-hover flex flex-col justify-between min-h-[150px]">
                <div>
                  <div className="w-10 h-10 rounded-full bg-brand-gold/20 text-brand-gold flex items-center justify-center mb-3 shadow-tactile-sm">
                    <SparklesIcon className="w-5 h-5 text-brand-gold" />
                  </div>
                  <h4 className="text-sm font-bold text-brand-chocolate font-sans">Pure & Honest</h4>
                  <p className="text-xs text-brand-chocolate/75 mt-1.5 leading-relaxed">
                    100% pure vegetarian recipes, fresh dairy cream, and zero artificial shortcuts.
                  </p>
                </div>
              </Card>

              <Card className="story-value-card p-5 bg-white border border-brand-border/80 shadow-tactile hover:shadow-tactile-hover flex flex-col justify-between min-h-[150px]">
                <div>
                  <div className="w-10 h-10 rounded-full bg-brand-cream text-brand-chocolate flex items-center justify-center mb-3 border border-brand-border shadow-tactile-sm">
                    <MapPinIcon className="w-5 h-5 text-brand-crimson" />
                  </div>
                  <h4 className="text-sm font-bold text-brand-chocolate font-sans">Jaunpur Heart</h4>
                  <p className="text-xs text-brand-chocolate/75 mt-1.5 leading-relaxed">
                    Proudly rooted at Line Bazaar, Dev Palace, serving our city with genuine warmth.
                  </p>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
