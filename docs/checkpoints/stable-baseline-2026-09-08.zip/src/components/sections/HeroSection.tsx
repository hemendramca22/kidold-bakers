"use client";

import React, { useRef, useEffect } from "react";
import { Container } from "@/components/ui/Container";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { HeroAtmosphere } from "@/components/sections/hero/HeroAtmosphere";
import { HeroProductStage } from "@/components/sections/hero/HeroProductStage";
import { WhatsAppIcon, SparklesIcon, HeartSparkleIcon } from "@/components/icons";
import { getWhatsAppInquiryUrl } from "@/lib/whatsapp";
import { registerGSAP, shouldReduceMotion } from "@/lib/motion";

export function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window === "undefined" || shouldReduceMotion()) return;

    const { gsap } = registerGSAP();
    const ctx = gsap.context(() => {
      // 1. Initial Page Load Entrance Choreography
      const tl = gsap.timeline({ defaults: { ease: "power3.out" } });

      tl.fromTo(
        ".hero-anim-kicker",
        { y: 10, scale: 0.98 },
        { y: 0, scale: 1, duration: 0.45 }
      )
        .fromTo(
          ".hero-anim-title-line",
          { y: 18 },
          { y: 0, duration: 0.55, stagger: 0.08 },
          "-=0.32"
        )
        .fromTo(
          ".hero-anim-desc",
          { y: 12 },
          { y: 0, duration: 0.45 },
          "-=0.35"
        )
        .fromTo(
          ".hero-anim-cta",
          { y: 10 },
          { y: 0, duration: 0.4 },
          "-=0.32"
        )
        .fromTo(
          ".hero-anim-occasions",
          { y: 8 },
          { y: 0, duration: 0.4 },
          "-=0.28"
        )
        .fromTo(
          ".hero-anim-trust",
          { y: 6 },
          { y: 0, duration: 0.35 },
          "-=0.25"
        );

      // Product Stage Reveal
      if (stageRef.current) {
        gsap.fromTo(
          stageRef.current,
          { scale: 0.97, y: 16 },
          { scale: 1, y: 0, duration: 0.65, ease: "power2.out" }
        );

        // Staggered floating badges entrance
        gsap.fromTo(
          ".hero-floating-badge",
          { scale: 0.94, y: 8 },
          {
            scale: 1,
            y: 0,
            duration: 0.45,
            ease: "back.out(1.4)",
            stagger: 0.06,
          }
        );

        // Restrained section exit transition (only activates as hero scrolls out of view)
        if (window.innerWidth >= 768 && sectionRef.current) {
          gsap.to(stageRef.current, {
            scale: 0.97,
            opacity: 0.9,
            ease: "power1.out",
            scrollTrigger: {
              trigger: sectionRef.current,
              start: "center top",
              end: "bottom top",
              scrub: true,
            },
          });
        }
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative overflow-hidden -mt-[70px] sm:-mt-[76px] pt-[96px] sm:pt-[118px] pb-16 sm:pb-20 lg:py-24 xl:py-28 bg-[#FAF5ED]"
    >
      {/* Plane 0 & Plane 1: Atmospheric Canvas & Behind-Navbar Lighting Layer */}
      <HeroAtmosphere />

      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-y-6 lg:gap-y-0 lg:gap-x-8 xl:gap-x-12 items-center">
          
          {/* Top Block: Editorial Kicker & Grand Headline */}
          <div className="order-1 lg:col-start-1 lg:col-span-6 xl:col-span-5 lg:row-start-1 space-y-4 sm:space-y-5 text-center lg:text-left relative z-10">
            {/* Editorial Kicker Badge */}
            <div className="hero-anim-kicker inline-flex flex-wrap items-center justify-center lg:justify-start gap-2">
              <Badge variant="crimson" className="font-bold px-3.5 py-1 shadow-tactile-sm text-xs uppercase tracking-wider">
                <SparklesIcon className="w-3.5 h-3.5 text-brand-crimson shrink-0" />
                <span>Est. Jaunpur • Artisan Patisserie</span>
              </Badge>
              <Badge variant="gold" className="hidden sm:inline-flex shadow-tactile-sm text-xs font-semibold">
                <HeartSparkleIcon className="w-3.5 h-3.5 text-brand-chocolate shrink-0" />
                <span>Where Legacy Meets Indulgence</span>
              </Badge>
            </div>

            {/* Grand Editorial Headline */}
            <div className="hero-editorial-headline space-y-1">
              <h1 className="text-4xl sm:text-6xl lg:text-6xl xl:text-7xl font-serif font-black text-brand-chocolate tracking-tight leading-[1.08]">
                <span className="hero-anim-title-line block">
                  You Imagine.
                </span>
                <span className="hero-anim-title-line block mt-1 sm:mt-1.5">
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-crimson via-brand-apricot to-brand-gold">
                    We Bake.
                  </span>
                </span>
              </h1>
            </div>
          </div>

          {/* Product Stage: On Mobile, sits prominently as order-2 directly below headline. On Desktop, sits in right column spanning rows 1-2 */}
          <div className="order-2 lg:col-start-7 lg:col-span-6 xl:col-span-7 lg:row-start-1 lg:row-span-2 flex justify-center lg:justify-end items-center relative z-20 py-2 sm:py-4 lg:py-0">
            <HeroProductStage ref={stageRef} />
          </div>

          {/* Bottom Block: Narrative, CTAs, Occasions & Consultation */}
          <div className="order-3 lg:col-start-1 lg:col-span-6 xl:col-span-5 lg:row-start-2 space-y-5 sm:space-y-6 text-center lg:text-left relative z-10 lg:pt-3">
            {/* Narrative Editorial Copy */}
            <p className="hero-anim-desc text-base sm:text-lg lg:text-lg xl:text-xl text-brand-chocolate/85 max-w-xl mx-auto lg:mx-0 leading-relaxed font-sans">
              From cherished first birthday milestones to golden anniversaries, we sculpt sweet memories across generations in Jaunpur. 100% pure vegetarian confectionery artistry baked daily with pure passion at Dev Palace, Line Bazaar.
            </p>

            {/* Conversion CTA Command Center — Compact, refined tactile styling */}
            <div className="hero-anim-cta flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 pt-1">
              <Button
                variant="primary"
                size="md"
                href="#custom-cakes"
                leftIcon={<SparklesIcon className="w-4 h-4" />}
                className="w-full sm:w-auto min-h-[44px] px-5 sm:px-6 py-2.5 text-sm sm:text-base font-semibold shadow-tactile whitespace-nowrap"
              >
                Design My Cake
              </Button>
              <Button
                variant="outline"
                size="md"
                href="#signature-cakes"
                className="w-full sm:w-auto min-h-[44px] px-5 sm:px-6 py-2.5 text-sm sm:text-base font-semibold shadow-tactile-sm whitespace-nowrap"
              >
                Explore Signature Bakes
              </Button>
            </div>

            {/* Occasion Quick-Links Pill Strip */}
            <div className="hero-anim-occasions pt-1">
              <div className="text-[11px] sm:text-xs font-bold uppercase tracking-wider text-brand-chocolate-light mb-2">
                Popular Occasions:
              </div>
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-1.5">
                {[
                  { label: "🎂 1st & Landmark Birthdays", href: "#custom-cakes" },
                  { label: "💍 Golden Anniversaries", href: "#custom-cakes" },
                  { label: "🎈 Kids Theme Cakes", href: "#custom-cakes" },
                  { label: "☕ Chai & Teatime Bakes", href: "#signature-cakes" },
                ].map((item) => (
                  <a
                    key={item.label}
                    href={item.href}
                    className="text-xs px-3 py-1 rounded-full bg-white/85 border border-brand-border/85 text-brand-chocolate/85 hover:border-brand-gold hover:bg-brand-cream hover:text-brand-crimson shadow-tactile-sm transition-all"
                  >
                    {item.label}
                  </a>
                ))}
              </div>
            </div>

            {/* Real-Time Bakery Trust & WhatsApp Consultation Strip */}
            <div className="hero-anim-trust pt-1 flex flex-wrap items-center justify-center lg:justify-start gap-3 text-xs text-brand-chocolate-light font-medium">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Counter Pickups & Enquiries Open Daily
              </span>
              <span>•</span>
              <a
                href={getWhatsAppInquiryUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-brand-crimson underline inline-flex items-center gap-1 font-semibold text-brand-chocolate"
              >
                <WhatsAppIcon className="w-3.5 h-3.5 text-brand-crimson shrink-0" />
                Direct WhatsApp Consultation
              </a>
            </div>
          </div>

        </div>
      </Container>
    </section>
  );
}
