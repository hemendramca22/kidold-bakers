"use client";

import React, { useRef, useEffect } from "react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { businessData } from "@/data/business";
import { MapPinIcon, PhoneIcon, WhatsAppIcon, ClockIcon } from "@/components/icons";
import { getWhatsAppInquiryUrl } from "@/lib/whatsapp";
import { registerGSAP, shouldReduceMotion, animateHeadingReveal } from "@/lib/motion";

export function LocalBusinessSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const leftColRef = useRef<HTMLDivElement>(null);
  const rightColRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window === "undefined" || shouldReduceMotion()) return;

    const { gsap } = registerGSAP();
    const ctx = gsap.context(() => {
      // 1. Masked Heading Reveal
      if (headingRef.current) {
        animateHeadingReveal(headingRef.current);
      }

      // 2. Left Column: Store Details Entrance
      if (leftColRef.current) {
        gsap.fromTo(
          leftColRef.current,
          { opacity: 0, y: 32 },
          {
            opacity: 1,
            y: 0,
            duration: 0.75,
            ease: "power2.out",
            scrollTrigger: {
              trigger: sectionRef.current,
              start: "top 80%",
              toggleActions: "play none none none",
            },
          }
        );
      }

      // 3. Right Column: Planning & Map Card Entrance
      if (rightColRef.current) {
        gsap.fromTo(
          rightColRef.current,
          { opacity: 0, y: 36 },
          {
            opacity: 1,
            y: 0,
            duration: 0.75,
            delay: 0.12,
            ease: "power2.out",
            scrollTrigger: {
              trigger: sectionRef.current,
              start: "top 80%",
              toggleActions: "play none none none",
            },
          }
        );

        // Desktop subtle map depth
        if (window.innerWidth >= 768) {
          const mapEl = rightColRef.current.querySelector(".local-map-card");
          if (mapEl) {
            gsap.fromTo(
              mapEl,
              { scale: 0.98 },
              {
                scale: 1.02,
                ease: "none",
                scrollTrigger: {
                  trigger: rightColRef.current,
                  start: "top bottom",
                  end: "bottom top",
                  scrub: 0.7,
                },
              }
            );
          }
        }
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} id="visit-us" className="py-16 sm:py-24 bg-brand-cream relative">
      <Container>
        <div ref={headingRef}>
          <SectionHeading
            badge="Visit Us"
            title="Visit Us at Line Bazaar, Jaunpur"
            subtitle="Stop by our bakery counter for warm evening pastries, or get your celebratory cakes delivered safely across Jaunpur city."
            align="center"
          />
        </div>

        <div className="mt-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Column: Business & Store Details */}
          <div ref={leftColRef} className="lg:col-span-6 flex flex-col justify-between space-y-6">
            <Card className="p-6 sm:p-8 bg-white border border-brand-border/80 shadow-tactile space-y-6">
              <div className="flex items-center justify-between pb-2 border-b border-brand-border/60">
                <h3 className="text-2xl font-bold font-serif text-brand-chocolate">
                  Bakery Counter &amp; Pickups
                </h3>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                  Baking Daily
                </span>
              </div>

              <div className="space-y-4 text-sm text-brand-chocolate/85">
                {/* Verified Address */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-full bg-brand-gold/15 text-brand-gold flex items-center justify-center shrink-0 mt-0.5 shadow-tactile-sm">
                    <MapPinIcon className="w-5 h-5 text-brand-gold" />
                  </div>
                  <div>
                    <div className="font-semibold text-brand-chocolate">Bakery Counter Address</div>
                    <div className="text-brand-chocolate/85 leading-relaxed mt-0.5 font-medium">
                      {businessData.addressLine}
                    </div>
                    <div className="text-xs text-brand-chocolate/75 mt-0.5">
                      {businessData.landmark}, {businessData.area}
                    </div>
                    <div className="text-xs text-brand-crimson mt-1 font-semibold">
                      {businessData.city}, {businessData.state}, India — PIN {businessData.pincode}
                    </div>
                  </div>
                </div>

                {/* Operating & Contact Status */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-full bg-brand-crimson/10 text-brand-crimson flex items-center justify-center shrink-0 mt-0.5 shadow-tactile-sm">
                    <ClockIcon className="w-5 h-5 text-brand-crimson" />
                  </div>
                  <div>
                    <div className="font-semibold text-brand-chocolate">Counter Pickups &amp; Enquiries</div>
                    <div className="text-brand-chocolate/75 mt-0.5 text-xs sm:text-sm">
                      {businessData.openingHoursDisplay}
                    </div>
                  </div>
                </div>

                {/* Direct Telephone & Email */}
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-full bg-brand-cream text-brand-chocolate flex items-center justify-center shrink-0 mt-0.5 border border-brand-border shadow-tactile-sm">
                    <PhoneIcon className="w-5 h-5 text-brand-gold" />
                  </div>
                  <div>
                    <div className="font-semibold text-brand-chocolate">Direct Phone &amp; Email</div>
                    <div className="mt-0.5">
                      <a
                        href={`tel:${businessData.phoneRaw}`}
                        className="text-brand-crimson font-bold text-sm hover:underline"
                      >
                        {businessData.phoneDisplay}
                      </a>
                    </div>
                    <div className="text-xs text-brand-chocolate/75 mt-0.5">
                      <a href={`mailto:${businessData.email}`} className="hover:underline">
                        {businessData.email}
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Direct Actions */}
              <div className="pt-4 border-t border-brand-border/60 flex flex-col sm:flex-row gap-3">
                <Button
                  variant="whatsapp"
                  size="md"
                  href={getWhatsAppInquiryUrl()}
                  isExternal
                  leftIcon={<WhatsAppIcon className="w-4 h-4 text-brand-gold" />}
                  className="flex-1 shadow-tactile-sm"
                >
                  WhatsApp Consultation
                </Button>
                <Button
                  variant="outline"
                  size="md"
                  href={`tel:${businessData.phoneRaw}`}
                  leftIcon={<PhoneIcon className="w-4 h-4" />}
                  className="flex-1"
                >
                  Call Bakery Counter
                </Button>
              </div>
            </Card>
          </div>

          {/* Right Column: Interactive Map Placeholder & Guidance */}
          <div ref={rightColRef} className="lg:col-span-6 flex flex-col justify-between">
            <Card className="p-6 sm:p-8 bg-gradient-to-b from-brand-cream to-brand-cream-warm border border-brand-border/80 shadow-tactile flex flex-col justify-between h-full space-y-6">
              <div>
                <h4 className="text-xl font-bold font-serif text-brand-chocolate">
                  Planning Your Celebration in Jaunpur?
                </h4>
                <p className="text-sm text-brand-chocolate/80 mt-2 leading-relaxed">
                  We recommend reserving multi-tier celebration cakes <strong>24 to 48 hours in advance</strong> so our master decorators can sculpt your vision with perfection.
                </p>

                {/* Map Graphic Card */}
                <div className="local-map-card mt-6 rounded-2xl overflow-hidden border border-brand-gold/40 relative bg-gradient-to-b from-brand-chocolate to-brand-chocolate-dark p-6 text-center text-white space-y-3 shadow-chocolate-tactile transition-transform duration-300">
                  <div className="w-12 h-12 rounded-full bg-brand-crimson text-white mx-auto flex items-center justify-center shadow-lg">
                    <MapPinIcon className="w-6 h-6" />
                  </div>
                  <h5 className="font-bold text-base text-brand-cream font-serif">
                    KidOld Bakers — Jaunpur Hub
                  </h5>
                  <p className="text-xs text-brand-cream/70 max-w-sm mx-auto">
                    Dev Palace, Line Bazaar Rd (beside S.P Aawas / Front Police Line Gate), Husainabad, Jaunpur 222002
                  </p>
                  <div className="pt-2">
                    <Button
                      variant="gold"
                      size="sm"
                      href={businessData.googleMapsUrl}
                      isExternal
                      leftIcon={<MapPinIcon className="w-4 h-4 text-brand-chocolate" />}
                    >
                      Open in Google Maps
                    </Button>
                  </div>
                </div>
              </div>

              {/* Order Tip */}
              <div className="p-4 rounded-xl bg-white/90 border border-brand-border/80 text-xs text-brand-chocolate/80 shadow-tactile-sm">
                <span className="font-bold text-brand-crimson">💡 Baker&apos;s Tip:</span> Planning a celebration or looking for same-day options? Message us directly on WhatsApp to confirm fresh ready-to-decorate tiers available today!
              </div>
            </Card>
          </div>
        </div>
      </Container>
    </section>
  );
}
