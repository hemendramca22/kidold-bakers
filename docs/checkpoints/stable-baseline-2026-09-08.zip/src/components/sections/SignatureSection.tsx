"use client";

import React, { useState, useRef, useEffect } from "react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Card } from "@/components/ui/Card";
import { Badge, VegIndicator } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { SafeImage } from "@/components/ui/SafeImage";
import { CardTiltWrapper } from "@/components/ui/CardTiltWrapper";
import { WhatsAppIcon, SparklesIcon } from "@/components/icons";
import { catalogService } from "@/services/catalogService";
import { resolveCatalogImage } from "@/types/category";
import { ProductOccasion } from "@/types/product";
import { getWhatsAppInquiryUrl } from "@/lib/whatsapp";
import { registerGSAP, shouldReduceMotion, animateHeadingReveal } from "@/lib/motion";

type OccasionFilter = "all" | ProductOccasion;

const FILTER_TABS: Array<{ id: OccasionFilter; label: string }> = [
  { id: "all", label: "All Cakes" },
  { id: "birthdays", label: "Birthday" },
  { id: "anniversaries", label: "Anniversary" },
  { id: "kids", label: "Kids" },
  { id: "celebrations", label: "Celebration" },
  { id: "teatime", label: "Tea-Time / Desserts" },
];

export function SignatureSection() {
  const [activeFilter, setActiveFilter] = useState<OccasionFilter>("all");
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const tabsRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const reassuranceRef = useRef<HTMLDivElement>(null);

  const allProducts = catalogService.getProductsSync();
  const filteredProducts =
    activeFilter === "all"
      ? allProducts
      : catalogService.getProductsSync({ occasion: activeFilter });

  // Adaptive harmonious layout configuration: guarantees centered incomplete rows,
  // balanced row pairs (3+3 for 6, 2+2 for 4, 3+2 for 5), and zero isolated dead columns.
  const count = filteredProducts.length;

  let containerMaxWidth = "max-w-6xl mx-auto";
  let cardClass = "signature-card-item signature-card-item-3col";

  if (count === 1) {
    containerMaxWidth = "max-w-md mx-auto";
    cardClass = "signature-card-item signature-card-item-1col";
  } else if (count === 2) {
    containerMaxWidth = "max-w-3xl mx-auto";
    cardClass = "signature-card-item signature-card-item-2col";
  } else if (count === 3) {
    containerMaxWidth = "max-w-6xl mx-auto";
    cardClass = "signature-card-item signature-card-item-3col";
  } else if (count === 4) {
    containerMaxWidth = "max-w-3xl lg:max-w-4xl xl:max-w-7xl mx-auto";
    cardClass = "signature-card-item signature-card-item-4item";
  } else if (count === 5) {
    containerMaxWidth = "max-w-6xl mx-auto";
    cardClass = "signature-card-item signature-card-item-3col";
  } else if (count === 6) {
    containerMaxWidth = "max-w-6xl mx-auto";
    cardClass = "signature-card-item signature-card-item-3col";
  } else if (count === 7) {
    containerMaxWidth = "max-w-6xl mx-auto";
    cardClass = "signature-card-item signature-card-item-7item";
  } else if (count >= 8) {
    containerMaxWidth = "max-w-6xl xl:max-w-7xl mx-auto";
    cardClass = "signature-card-item signature-card-item-3col xl:signature-card-item-4col";
  }

  // Initial ScrollTrigger entrance animations
  useEffect(() => {
    if (typeof window === "undefined" || shouldReduceMotion()) return;

    const { gsap } = registerGSAP();
    const ctx = gsap.context(() => {
      // 1. Masked/Staggered Heading Reveal
      if (headingRef.current) {
        animateHeadingReveal(headingRef.current);
      }

      // 2. Filter Tabs Reveal
      if (tabsRef.current) {
        gsap.fromTo(
          tabsRef.current,
          { opacity: 0, y: 16 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            ease: "power2.out",
            scrollTrigger: {
              trigger: tabsRef.current,
              start: "top 85%",
              toggleActions: "play none none none",
            },
          }
        );
      }

      // 3. Staggered Product Cards Initial Entrance
      if (gridRef.current) {
        const cards = gridRef.current.querySelectorAll(".product-card-item");
        gsap.fromTo(
          cards,
          { opacity: 0, y: 32 },
          {
            opacity: 1,
            y: 0,
            duration: 0.7,
            stagger: 0.08,
            ease: "power2.out",
            scrollTrigger: {
              trigger: gridRef.current,
              start: "top 85%",
              toggleActions: "play none none none",
            },
          }
        );

        // 4. Subtle image scale-on-scroll parallax (Desktop only)
        if (window.innerWidth >= 768) {
          cards.forEach((card) => {
            const img = card.querySelector(".product-scale-image");
            if (img) {
              gsap.fromTo(
                img,
                { scale: 1.0 },
                {
                  scale: 1.05,
                  ease: "none",
                  scrollTrigger: {
                    trigger: card,
                    start: "top bottom",
                    end: "bottom top",
                    scrub: 0.6,
                  },
                }
              );
            }
          });
        }
      }

      // 5. Reassurance Banner Reveal
      if (reassuranceRef.current) {
        gsap.fromTo(
          reassuranceRef.current,
          { opacity: 0, y: 20 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            ease: "power2.out",
            scrollTrigger: {
              trigger: reassuranceRef.current,
              start: "top 90%",
              toggleActions: "play none none none",
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Filter switch animation: smoothly animate newly filtered cards
  useEffect(() => {
    if (typeof window === "undefined" || shouldReduceMotion()) return;

    const { gsap, ScrollTrigger } = registerGSAP();
    const ctx = gsap.context(() => {
      if (gridRef.current) {
        const cards = gridRef.current.querySelectorAll(".product-card-item");
        gsap.fromTo(
          cards,
          { opacity: 0, y: 16 },
          {
            opacity: 1,
            y: 0,
            duration: 0.45,
            stagger: 0.06,
            ease: "power2.out",
          }
        );
        ScrollTrigger.refresh();
      }
    }, sectionRef);

    return () => ctx.revert();
  }, [activeFilter]);

  return (
    <section
      ref={sectionRef}
      id="signature-cakes"
      className="py-16 sm:py-20 bg-brand-cream-warm overflow-hidden"
    >
      <Container>
        <div ref={headingRef}>
          <SectionHeading
            badge="Signature Cakes"
            title="Signature Cakes & Handcrafted Bakes"
            subtitle="Celebration centerpieces crafted for birthdays, anniversaries, and family milestones in Jaunpur. 100% pure vegetarian / eggless options available."
            align="center"
          />
        </div>

        {/* One Obvious Primary Filter System */}
        <div
          ref={tabsRef}
          className="mt-8 sm:mt-10 flex flex-wrap items-center justify-center gap-2 sm:gap-2.5 max-w-3xl mx-auto"
        >
          {FILTER_TABS.map((tab) => {
            const isActive = activeFilter === tab.id;

            return (
              <button
                key={tab.id}
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  setActiveFilter(tab.id);
                }}
                className={`inline-flex items-center px-4 sm:px-5 py-2 rounded-full text-xs sm:text-sm font-semibold transition-all duration-200 border cursor-pointer select-none ${
                  isActive
                    ? "bg-brand-crimson text-white font-bold border-brand-crimson shadow-crimson-tactile scale-[1.03]"
                    : "bg-white/85 text-brand-chocolate/80 border-brand-border/80 hover:bg-[#FDFBF7] hover:border-brand-gold/60 hover:text-brand-chocolate shadow-tactile-sm active:scale-95"
                }`}
                aria-pressed={isActive}
              >
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Products Grid — Adaptive Harmonious Multi-Row Centered Layout */}
        <div className={`mt-10 ${containerMaxWidth}`}>
          <div
            ref={gridRef}
            className="signature-grid-container"
          >
          {filteredProducts.map((product) => {
            const imageAsset = resolveCatalogImage(
              product.image,
              `${product.name} - Handcrafted Cake at KidOld Bakers Jaunpur`
            );

            return (
              <CardTiltWrapper
                key={product.id}
                className={`product-card-item ${cardClass}`}
              >
                <Card className="group flex flex-col h-full bg-white border border-brand-border/80 shadow-tactile hover:shadow-tactile-hover hover:border-brand-gold/60 transition-[box-shadow,border-color] duration-300">
                  {/* Product Image Frame */}
                  <div className="relative h-64 w-full overflow-hidden bg-brand-cream">
                    <div className="card-parallax-image w-full h-full relative">
                      <SafeImage
                        src={imageAsset.src}
                        alt={imageAsset.alt}
                        fallbackLabel={product.name}
                        fill
                        sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, (max-width: 1280px) 33vw, 25vw"
                        className="product-scale-image object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    </div>

                    {/* Top Badges */}
                    <div className="absolute top-3 left-3 flex flex-wrap gap-2 items-center pointer-events-none">
                      {product.isPureVeg && (
                        <div className="bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-full shadow-tactile-sm flex items-center gap-1.5 text-xs font-bold text-emerald-800 border border-emerald-200">
                          <VegIndicator />
                          <span>Pure Veg</span>
                        </div>
                      )}
                      {product.isSignature && (
                        <Badge variant="crimson" className="font-bold shadow-tactile-sm">
                          Signature
                        </Badge>
                      )}
                    </div>

                    {/* Tactile Action Tag */}
                    <div className="absolute bottom-3 right-3 bg-brand-chocolate/95 backdrop-blur-xs text-brand-gold-sparkle px-3 py-1 rounded-full text-[11px] font-bold shadow-chocolate-tactile border border-brand-gold/40 pointer-events-none">
                      {product.enquiryActionText || "Enquire on WhatsApp"}
                    </div>
                  </div>

                  {/* Product Info & Microcopy */}
                  <div className="p-6 flex flex-col flex-1 justify-between space-y-4">
                    <div className="space-y-2">
                      <div className="text-[11px] font-bold text-brand-crimson uppercase tracking-wider">
                        {product.categoryName}
                      </div>
                      <h3 className="text-lg font-bold text-brand-chocolate font-sans group-hover:text-brand-crimson transition-colors">
                        {product.name}
                      </h3>
                      <p className="text-sm text-brand-chocolate/75 leading-relaxed">
                        {product.shortDescription}
                      </p>

                      {/* Flavor Notes Chips */}
                      <div className="flex flex-wrap gap-1.5 pt-2">
                        {product.flavorNotes.map((note) => (
                          <span
                            key={note}
                            className="text-[11px] bg-brand-cream text-brand-chocolate/80 font-medium px-2.5 py-0.5 rounded-md border border-brand-border/70 shadow-2xs"
                          >
                            {note}
                          </span>
                        ))}
                      </div>

                      {/* Weight Options */}
                      {product.weightOptions && product.weightOptions.length > 0 && (
                        <div className="text-xs text-brand-chocolate-light pt-1.5">
                          <span className="font-semibold text-brand-chocolate">Sizes / Portions:</span>{" "}
                          {product.weightOptions.join(" • ")}
                        </div>
                      )}

                      {product.bakerNote && (
                        <div className="text-xs italic text-brand-chocolate/70 pt-1 border-t border-brand-border/40">
                          💡 {product.bakerNote}
                        </div>
                      )}
                    </div>

                    {/* Tactile Order Action */}
                    <div className="pt-3 border-t border-brand-border/60">
                      <div className="card-tilt-cta transition-transform duration-200">
                        <Button
                          variant="whatsapp"
                          size="sm"
                          href={getWhatsAppInquiryUrl({
                            productName: product.name,
                            categoryName: product.categoryName,
                          })}
                          isExternal
                          leftIcon={<WhatsAppIcon className="w-4 h-4 text-brand-gold" />}
                          className="w-full text-xs shadow-tactile-sm"
                        >
                          {product.enquiryActionText ? `${product.enquiryActionText}` : "Inquire via WhatsApp"}
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              </CardTiltWrapper>
            );
          })}
          </div>
        </div>

        {/* Reassurance Banner */}
        <div
          ref={reassuranceRef}
          className="mt-12 p-6 rounded-2xl bg-white/80 border border-brand-border/80 shadow-tactile-sm flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left"
        >
          <div className="space-y-1">
            <h4 className="font-bold text-sm text-brand-chocolate flex items-center justify-center sm:justify-start gap-2">
              <SparklesIcon className="w-4 h-4 text-brand-gold" />
              <span>Looking for a custom weight, tiered stand, or specific dietary recipe?</span>
            </h4>
            <p className="text-xs text-brand-chocolate/75">
              Our Jaunpur bakers specialize in custom designs. Please confirm availability, custom weights, and advance booking timing with our bakery team on WhatsApp.
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            href={getWhatsAppInquiryUrl({ isCustomCake: true })}
            isExternal
            className="text-xs shrink-0"
          >
            Ask Chef on WhatsApp →
          </Button>
        </div>
      </Container>
    </section>
  );
}
