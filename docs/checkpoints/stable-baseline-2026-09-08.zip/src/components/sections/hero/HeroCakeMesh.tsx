"use client";

import React, { useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";

interface HeroCakeMeshProps {
  scrollProgress?: number | React.RefObject<number> | { current: number }; // 0 to 1
}

function getProgress(val: number | React.RefObject<number> | { current: number } | undefined): number {
  if (val === undefined) return 0;
  if (typeof val === "number") return val;
  return val.current ?? 0;
}

/**
 * HeroCakeMesh
 *
 * Modular 3D cake model architecture supporting:
 * - Deterministic 6-state scroll-scrubbed progression
 * - Layer separation / exploded view
 * - High-end PBR materials with KidOld brand tokens
 * - Prepared for drop-in real GLB asset replacement at public/models/hero-cake.glb
 */
export function HeroCakeMesh({ scrollProgress = 0 }: HeroCakeMeshProps) {
  const rootGroup = useRef<THREE.Group>(null);
  const tier2Group = useRef<THREE.Group>(null);
  const topperGroup = useRef<THREE.Group>(null);
  const compoteDisc = useRef<THREE.Mesh>(null);

  // Target values derived from scroll progress
  // State 1 (0.0 - 0.15): Front view
  // State 2 (0.15 - 0.35): Turntable rotation (~0.65 rad / 37 deg)
  // State 3 (0.35 - 0.55): Macro camera dolly / scale
  // State 4 (0.55 - 0.75): Callout detail focus
  // State 5 (0.75 - 0.90): Exploded layer separation
  // State 6 (0.90 - 1.00): Reassembly into finished centerpiece

  useFrame(() => {
    if (!rootGroup.current || !tier2Group.current || !topperGroup.current) return;

    const p = THREE.MathUtils.clamp(getProgress(scrollProgress), 0, 1);

    // 1. Rotation progression
    let targetRotationY = 0;
    if (p < 0.15) {
      targetRotationY = 0;
    } else if (p < 0.55) {
      // Rotate 38 degrees
      const localT = (p - 0.15) / 0.4;
      targetRotationY = THREE.MathUtils.lerp(0, 0.66, localT);
    } else if (p < 0.75) {
      // Hold steady for callouts
      targetRotationY = 0.66;
    } else if (p < 0.9) {
      // Subtle turn during exploded view
      const localT = (p - 0.75) / 0.15;
      targetRotationY = THREE.MathUtils.lerp(0.66, 0.45, localT);
    } else {
      // Recompose to front
      const localT = (p - 0.9) / 0.1;
      targetRotationY = THREE.MathUtils.lerp(0.45, 0.08, localT);
    }

    // 2. Exploded layer separation (State 5)
    let targetTier2Y = 0.85; // default stacked position
    let targetTopperY = 1.6; // default stacked position
    let compoteOpacity = 0;

    if (p >= 0.75 && p < 0.9) {
      const localT = Math.sin(((p - 0.75) / 0.15) * Math.PI); // smooth bell curve separation
      targetTier2Y = 0.85 + localT * 0.45; // lift tier 2 by 0.45 units
      targetTopperY = 1.6 + localT * 0.8; // lift topper by 0.8 units
      compoteOpacity = localT;
    }

    // Smooth dampening towards target values
    rootGroup.current.rotation.y = THREE.MathUtils.lerp(
      rootGroup.current.rotation.y,
      targetRotationY,
      0.12
    );

    tier2Group.current.position.y = THREE.MathUtils.lerp(
      tier2Group.current.position.y,
      targetTier2Y,
      0.15
    );

    topperGroup.current.position.y = THREE.MathUtils.lerp(
      topperGroup.current.position.y,
      targetTopperY,
      0.15
    );

    if (compoteDisc.current) {
      const mat = compoteDisc.current.material as THREE.MeshStandardMaterial;
      mat.opacity = THREE.MathUtils.lerp(mat.opacity, compoteOpacity, 0.15);
      mat.transparent = true;
    }
  });

  return (
    <group ref={rootGroup} position={[0, -0.65, 0]} dispose={null}>
      {/* 1. ARTISAN PEDESTAL / TURNTABLE BASE */}
      <group position={[0, 0, 0]}>
        {/* Foot Base */}
        <mesh position={[0, 0.04, 0]} receiveShadow>
          <cylinderGeometry args={[0.75, 0.95, 0.08, 36]} />
          <meshStandardMaterial
            color="#D8AA42"
            roughness={0.28}
            metalness={0.2}
          />
        </mesh>

        {/* Stem Column */}
        <mesh position={[0, 0.28, 0]} receiveShadow castShadow>
          <cylinderGeometry args={[0.22, 0.38, 0.4, 32]} />
          <meshStandardMaterial
            color="#C69734"
            roughness={0.3}
            metalness={0.15}
          />
        </mesh>

        {/* Platter Plate */}
        <mesh position={[0, 0.48, 0]} receiveShadow castShadow>
          <cylinderGeometry args={[1.35, 1.25, 0.06, 48]} />
          <meshStandardMaterial
            color="#E4B853"
            roughness={0.22}
            metalness={0.35}
          />
        </mesh>

        {/* Platter Gold Beveled Rim */}
        <mesh position={[0, 0.5, 0]}>
          <torusGeometry args={[1.33, 0.025, 16, 48]} />
          <meshStandardMaterial
            color="#FAF0D7"
            roughness={0.18}
            metalness={0.65}
          />
        </mesh>
      </group>

      {/* 2. TIER 1: BOTTOM CELEBRATION TIER (Dutch Cocoa & Cream) */}
      <group position={[0, 0.52, 0]}>
        {/* Cake Sponge Cylinder */}
        <mesh position={[0, 0.38, 0]} castShadow receiveShadow>
          <cylinderGeometry args={[1.05, 1.05, 0.72, 48]} />
          <meshStandardMaterial
            color="#FAF4EA"
            roughness={0.4}
            metalness={0.05}
          />
        </mesh>

        {/* Chocolate Ganache Drip Ring */}
        <mesh position={[0, 0.68, 0]} castShadow>
          <cylinderGeometry args={[1.07, 1.06, 0.16, 48]} />
          <meshStandardMaterial
            color="#26130B"
            roughness={0.2}
            metalness={0.15}
          />
        </mesh>

        {/* Exposed Compote / Filling Slice (Revealed during exploded State 5) */}
        <mesh ref={compoteDisc} position={[0, 0.75, 0]}>
          <cylinderGeometry args={[0.9, 0.9, 0.04, 36]} />
          <meshStandardMaterial
            color="#8B1528"
            roughness={0.25}
            metalness={0.1}
            opacity={0}
            transparent
          />
        </mesh>
      </group>

      {/* 3. TIER 2: TOP CELEBRATION TIER (Lifts vertically in State 5) */}
      <group ref={tier2Group} position={[0, 0.85, 0]}>
        {/* Sponge Cylinder */}
        <mesh position={[0, 0.38, 0]} castShadow receiveShadow>
          <cylinderGeometry args={[0.72, 0.72, 0.68, 48]} />
          <meshStandardMaterial
            color="#FFFDF7"
            roughness={0.35}
            metalness={0.05}
          />
        </mesh>

        {/* Dark Ganache Crown Drip */}
        <mesh position={[0, 0.66, 0]} castShadow>
          <cylinderGeometry args={[0.74, 0.73, 0.14, 48]} />
          <meshStandardMaterial
            color="#1F0E07"
            roughness={0.18}
            metalness={0.18}
          />
        </mesh>
      </group>

      {/* 4. TOPPER: FRESH BERRIES & GOLD EMBELLISHMENTS (Lifts highest in State 5) */}
      <group ref={topperGroup} position={[0, 1.6, 0]}>
        {/* Raspberry Centerpiece */}
        <mesh position={[0, 0.08, 0]} castShadow>
          <sphereGeometry args={[0.13, 24, 24]} />
          <meshStandardMaterial
            color="#A81C35"
            roughness={0.3}
            metalness={0.1}
          />
        </mesh>

        {/* Wild Blueberries */}
        <mesh position={[0.18, 0.06, 0.12]} castShadow>
          <sphereGeometry args={[0.09, 18, 18]} />
          <meshStandardMaterial
            color="#1D2A44"
            roughness={0.25}
            metalness={0.15}
          />
        </mesh>
        <mesh position={[-0.16, 0.05, -0.1]} castShadow>
          <sphereGeometry args={[0.08, 18, 18]} />
          <meshStandardMaterial
            color="#213252"
            roughness={0.25}
            metalness={0.15}
          />
        </mesh>

        {/* Gold Leaf Flakes / Celebration Plaque */}
        <mesh position={[0, 0.22, 0]} castShadow>
          <boxGeometry args={[0.34, 0.14, 0.02]} />
          <meshStandardMaterial
            color="#E5BE58"
            roughness={0.2}
            metalness={0.8}
          />
        </mesh>
      </group>
    </group>
  );
}
