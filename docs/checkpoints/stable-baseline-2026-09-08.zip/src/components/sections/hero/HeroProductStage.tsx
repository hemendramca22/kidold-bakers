"use client";

import React, { forwardRef } from "react";
import Image from "next/image";
import { SparklesIcon, HeartSparkleIcon } from "@/components/icons";
import { VegIndicator } from "@/components/ui/Badge";
import { heroMediaConfig } from "@/data/business";
export interface HeroProductStageProps {
  className?: string;
}

/**
 * HeroProductStage
 *
 * Plane 2 & Plane 3:
 * Dedicated architectural stage for the dominant hero celebration cake.
 * Features an artisan pedestal showcase, tactile floating badges, and studio lighting overlays.
 */
export const HeroProductStage = forwardRef<HTMLDivElement, HeroProductStageProps>(
  function HeroProductStage({ className = "" }, ref) {
    return (
      <div
        ref={ref}
        className={`hero-product-stage relative w-full max-w-[560px] sm:max-w-[620px] lg:max-w-[660px] xl:max-w-[720px] mx-auto select-none ${className}`}
        data-component="hero-product-stage"
      >
        {/* Platter / Turntable Floor Shadow & Ambient Depth */}
        <div
          className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-[85%] h-14 bg-brand-chocolate/25 blur-2xl rounded-full pointer-events-none -z-10"
          aria-hidden="true"
        />
        <div
          className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-[70%] h-8 bg-brand-chocolate/35 blur-md rounded-full pointer-events-none -z-10"
          aria-hidden="true"
        />

        {/* Studio Spotlight Halo directly illuminating the cake base */}
        <div
          className="hero-stage-halo absolute -inset-6 sm:-inset-10 rounded-[3rem] bg-[radial-gradient(ellipse_at_center,rgba(255,248,235,0.95)_0%,rgba(216,170,66,0.30)_40%,rgba(139,21,40,0.08)_65%,transparent_75%)] blur-2xl pointer-events-none -z-10"
          aria-hidden="true"
        />

        {/* Main Showcase Frame: Authentic High-Res Editorial Bakery Centerpiece */}
        <div className="hero-stage-visual relative">
          <div className="relative group w-full aspect-[4/3.7] sm:aspect-[4/3.4] lg:aspect-[4/3.5] rounded-[2.25rem] sm:rounded-[2.75rem] overflow-hidden bg-gradient-to-b from-[#FFFDF9] via-[#FAF3E8] to-[#F5E8D4] border-2 border-brand-gold/45 shadow-[0_28px_60px_-14px_rgba(44,24,16,0.26),0_14px_30px_-8px_rgba(216,170,66,0.20)]">
            {/* Centerpiece Celebration Cake Image — visually stable, high-res presentation */}
            <Image
              src={heroMediaConfig.authenticPhotoSrc}
              alt={heroMediaConfig.altText}
              fill
              priority
              sizes="(max-width: 640px) 94vw, (max-width: 1024px) 85vw, 680px"
              className="object-cover object-center"
            />

            {/* Artisan Specular Rim Light & Vignette Overlay */}
            <div
              className="absolute inset-0 bg-gradient-to-t from-brand-chocolate/45 via-transparent to-white/15 pointer-events-none"
              aria-hidden="true"
            />

            {/* Faint gold inner hairline shimmer */}
            <div
              className="absolute inset-0 rounded-[2.25rem] sm:rounded-[2.75rem] border border-white/40 pointer-events-none"
              aria-hidden="true"
            />
          </div>

          {/* Plane 3: Floating Tactile Badges with 3D Depth */}

          {/* Badge 1: Top-Right — 100% Handcrafted Artisan Studio */}
          <div
            className="hero-floating-badge absolute -top-3 sm:-top-5 -right-2 sm:-right-4 z-20 bg-white/95 backdrop-blur-md border border-brand-gold/60 shadow-tactile-lg px-3 sm:px-4 py-1.5 sm:py-2 rounded-full flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm font-bold text-brand-chocolate transition-all hover:scale-105"
          >
            <SparklesIcon className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-brand-gold-sparkle shrink-0" />
            <span>100% Handcrafted</span>
            <span className="hidden sm:inline text-brand-chocolate-light font-medium text-[11px]">• Artisan Studio</span>
          </div>

          {/* Badge 2: Bottom-Left — 100% Pure Veg */}
          <div
            className="hero-floating-badge absolute -bottom-3 sm:-bottom-5 -left-2 sm:-left-4 z-20 bg-brand-chocolate/95 backdrop-blur-md text-brand-cream border border-brand-gold/45 shadow-chocolate-tactile px-3 sm:px-4 py-1.5 sm:py-2 rounded-full flex items-center gap-2 text-xs sm:text-sm font-semibold transition-all hover:scale-105"
          >
            <VegIndicator className="w-3.5 sm:w-4 h-3.5 sm:h-4 shrink-0" />
            <span>100% Pure Veg</span>
            <span className="hidden sm:inline text-brand-gold/85 text-[11px] font-normal">• Eggless Perfection</span>
          </div>

          {/* Badge 3: Mid-Left — Bespoke 2-Tier Celebration */}
          <div
            className="hero-floating-badge absolute top-10 sm:top-14 -left-2 sm:-left-6 z-20 bg-brand-cream-warm/95 backdrop-blur-md border border-brand-gold/45 shadow-tactile px-3 py-1 sm:px-3.5 sm:py-1.5 rounded-full flex items-center gap-1.5 text-[11px] sm:text-xs font-bold text-brand-crimson transition-all hover:scale-105"
          >
            <HeartSparkleIcon className="w-3.5 h-3.5 text-brand-crimson shrink-0" />
            <span>Bespoke 2-Tier Celebration</span>
          </div>

          {/* Badge 4: Bottom-Right — Fresh Daily Batch in Jaunpur */}
          <div
            className="hero-floating-badge absolute bottom-6 sm:bottom-8 -right-2 sm:-right-4 z-20 bg-white/95 backdrop-blur-md border border-brand-border/90 shadow-tactile-sm px-3 py-1 rounded-full flex items-center gap-1.5 text-[11px] text-brand-chocolate/90 font-semibold"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
            <span>Fresh Daily Batch</span>
            <span className="hidden sm:inline text-brand-chocolate-light font-normal">• Jaunpur</span>
          </div>
        </div>
      </div>
    );
  }
);
