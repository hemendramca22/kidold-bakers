"use client";

import React, { useRef, useEffect, useState, Suspense } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { ContactShadows } from "@react-three/drei";
import { HeroCakeMesh } from "./HeroCakeMesh";

export interface HeroCakeSceneProps {
  scrollProgress?: number | React.RefObject<number> | { current: number }; // 0 to 1
  className?: string;
}

function getProgress(val: number | React.RefObject<number> | { current: number } | undefined): number {
  if (val === undefined) return 0;
  if (typeof val === "number") return val;
  return val.current ?? 0;
}

/**
 * Responsive Camera Controller
 * Manages macro zoom during State 3 (progress 0.35 - 0.55) and subtle desktop pointer tilt.
 */
function CameraRig({
  scrollProgress = 0,
}: {
  scrollProgress?: number | React.RefObject<number> | { current: number };
}) {
  const { camera } = useThree();
  const mouse = useRef({ x: 0, y: 0 });
  const isDesktop = useRef(false);

  useEffect(() => {
    isDesktop.current = window.innerWidth >= 1024;

    const handlePointerMove = (e: MouseEvent) => {
      if (!isDesktop.current) return;
      // Very restrained pointer offset (max ±0.08 units)
      mouse.current.x = (e.clientX / window.innerWidth - 0.5) * 0.16;
      mouse.current.y = (e.clientY / window.innerHeight - 0.5) * 0.12;
    };

    window.addEventListener("pointermove", handlePointerMove, { passive: true });
    return () => window.removeEventListener("pointermove", handlePointerMove);
  }, []);

  useFrame(() => {
    const p = THREE.MathUtils.clamp(getProgress(scrollProgress), 0, 1);

    // State 3: Macro dolly zoom (camera moves closer from z=4.4 to z=3.4)
    let targetZ = 4.4;
    let targetY = 0.35;

    if (p >= 0.35 && p < 0.55) {
      const localT = Math.sin(((p - 0.35) / 0.2) * Math.PI);
      targetZ = 4.4 - localT * 0.95; // dolly in closer for macro detail
      targetY = 0.35 + localT * 0.15; // angle slightly upwards
    }

    camera.position.z = THREE.MathUtils.lerp(camera.position.z, targetZ, 0.1);
    camera.position.y = THREE.MathUtils.lerp(camera.position.y, targetY + mouse.current.y, 0.1);
    camera.position.x = THREE.MathUtils.lerp(camera.position.x, mouse.current.x, 0.1);

    camera.lookAt(0, 0.25, 0);
  });

  return null;
}

/**
 * Detects whether WebGL is safely supported in the current client browser environment.
 */
function isWebGLAvailable(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const canvas = document.createElement("canvas");
    return Boolean(
      window.WebGLRenderingContext &&
        (canvas.getContext("webgl") || canvas.getContext("experimental-webgl"))
    );
  } catch {
    return false;
  }
}

/**
 * HeroCakeScene
 *
 * Dedicated R3F component boundary for the flagship 3D hero celebration cake.
 * Renders studio lighting, soft turntable shadows, and the scrubbed 3D model.
 */
export function HeroCakeScene({ scrollProgress = 0, className = "" }: HeroCakeSceneProps) {
  const [canRenderWebGL, setCanRenderWebGL] = useState(false);

  useEffect(() => {
    setCanRenderWebGL(isWebGLAvailable());
  }, []);

  if (!canRenderWebGL) {
    return null; // Fallback will render the approved static photo seamlessly
  }

  return (
    <div className={`relative w-full h-full select-none ${className}`} data-component="hero-cake-scene">
      <Canvas
        camera={{ position: [0, 0.35, 4.4], fov: 42 }}
        dpr={[1, 2]}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference: "high-performance",
        }}
        shadows
        className="w-full h-full"
      >
        {/* Studio Bakery Lighting Rig */}
        <ambientLight intensity={0.9} color="#FFF8ED" />

        {/* Primary Warm Key Light */}
        <directionalLight
          position={[3.5, 4.2, 3]}
          intensity={1.6}
          color="#FFE8CA"
          castShadow
          shadow-mapSize={[1024, 1024]}
          shadow-bias={-0.0001}
        />

        {/* Golden Specular Rim / Back Light */}
        <directionalLight
          position={[-3.5, 3.2, -2.5]}
          intensity={1.1}
          color="#E6BB5C"
        />

        {/* Gentle Ambient Floor / Fill Light */}
        <directionalLight
          position={[0, -2, 2.5]}
          intensity={0.5}
          color="#FAF0E3"
        />

        <Suspense fallback={null}>
          <CameraRig scrollProgress={scrollProgress} />
          <HeroCakeMesh scrollProgress={scrollProgress} />

          {/* Soft Ground Contact Shadow on Turntable Floor */}
          <ContactShadows
            position={[0, -0.66, 0]}
            opacity={0.65}
            scale={4.8}
            blur={1.8}
            far={2.5}
            color="#24120A"
          />
        </Suspense>
      </Canvas>
    </div>
  );
}

export default HeroCakeScene;
