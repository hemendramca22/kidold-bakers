import React, { forwardRef } from "react";

export interface HeroAtmosphereProps {
  className?: string;
}

export interface HeroAtmosphereRefs {
  driftA: HTMLDivElement | null;
  driftB: HTMLDivElement | null;
  spotlight: HTMLDivElement | null;
}

/**
 * HeroAtmosphere
 * 
 * Planes 0 & 1: Background canvas, atmospheric glow fields, and tactile confectionery textures.
 * Encapsulated as a reusable background layer for the cinematic hero environment.
 */
export const HeroAtmosphere = forwardRef<HTMLDivElement, HeroAtmosphereProps>(
  function HeroAtmosphere({ className = "" }, ref) {
    return (
      <div
        ref={ref}
        className={`absolute inset-0 pointer-events-none overflow-hidden select-none -z-10 ${className}`}
        aria-hidden="true"
      >
        {/* 1. Behind-Navbar Distinct Tonal Contrast Band — ensures glass transparency and blur are visible */}
        <div className="absolute top-0 inset-x-0 h-48 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-brand-crimson/[0.12] via-brand-gold/[0.18] to-brand-crimson/[0.10]" />
          <div className="absolute -top-8 left-1/2 -translate-x-1/2 w-[760px] h-44 bg-[radial-gradient(ellipse_at_center,rgba(216,170,66,0.32)_0%,rgba(139,21,40,0.12)_45%,transparent_80%)] blur-2xl" />
        </div>

        {/* 2. Top-Right Artisan Gold Chandelier Light Field */}
        <div
          className="hero-atmosphere-light-a absolute -top-20 -right-20 w-[600px] lg:w-[750px] h-[600px] lg:h-[750px] rounded-full bg-[radial-gradient(circle,rgba(216,170,66,0.28)_0%,rgba(216,170,66,0.08)_50%,transparent_70%)] blur-3xl"
        />

        {/* 3. Mid-Left Velvet Crimson & Chocolate Atmospheric Glow */}
        <div
          className="hero-atmosphere-light-b absolute top-24 -left-28 w-[540px] lg:w-[680px] h-[540px] lg:h-[680px] rounded-full bg-[radial-gradient(circle,rgba(139,21,40,0.18)_0%,rgba(139,21,40,0.05)_50%,transparent_75%)] blur-3xl"
        />

        {/* 4. Centerpiece Cake Confectionery Spotlight Halo */}
        <div
          className="hero-atmosphere-spotlight absolute top-1/2 right-1/4 -translate-y-1/2 w-[420px] sm:w-[540px] lg:w-[620px] h-[420px] sm:h-[540px] lg:h-[620px] rounded-full bg-[radial-gradient(circle_at_center,rgba(255,250,240,0.95)_0%,rgba(216,170,66,0.25)_40%,rgba(139,21,40,0.06)_65%,transparent_75%)] blur-3xl"
        />

        {/* 5. Bottom Chocolate Anchoring Vignette */}
        <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 w-[850px] h-[340px] rounded-full bg-[radial-gradient(ellipse_at_bottom,rgba(44,24,16,0.08)_0%,transparent_70%)] blur-2xl" />

        {/* 6. Tactile Flour/Paper Grain Texture */}
        <div
          className="absolute inset-0 opacity-[0.04] mix-blend-multiply"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
          }}
        />

        {/* 7. Fine Bakery Dot Texture Grid */}
        <div className="absolute inset-0 bg-[radial-gradient(#D4AF37_0.75px,transparent_0.75px)] [background-size:28px_28px] opacity-[0.10]" />
      </div>
    );
  }
);
