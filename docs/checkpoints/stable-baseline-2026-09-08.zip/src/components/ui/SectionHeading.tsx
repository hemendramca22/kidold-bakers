import React from "react";
import { cn } from "@/lib/utils";
import { SparklesIcon } from "@/components/icons";

interface SectionHeadingProps {
  badge?: string;
  title: string;
  subtitle?: string;
  align?: "center" | "left";
  className?: string;
}

export function SectionHeading({
  badge,
  title,
  subtitle,
  align = "center",
  className,
}: SectionHeadingProps) {
  return (
    <div
      className={cn(
        "max-w-2xl",
        align === "center" ? "mx-auto text-center" : "text-left",
        className
      )}
    >
      {badge && (
        <div
          className={cn(
            "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold tracking-wider uppercase text-brand-crimson bg-brand-crimson/10 border border-brand-crimson/20 mb-3",
            align === "center" && "mx-auto"
          )}
        >
          <SparklesIcon className="w-3.5 h-3.5 text-brand-crimson" />
          <span>{badge}</span>
        </div>
      )}
      <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-serif text-brand-chocolate tracking-tight leading-tight">
        {title}
      </h2>
      {subtitle && (
        <p className="mt-3.5 text-base sm:text-lg text-brand-chocolate/75 font-sans leading-relaxed">
          {subtitle}
        </p>
      )}
      <div
        className={cn(
          "w-16 h-1 bg-gradient-to-r from-brand-gold to-brand-crimson rounded-full mt-4",
          align === "center" ? "mx-auto" : "ml-0"
        )}
      />
    </div>
  );
}
