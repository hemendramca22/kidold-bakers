"use client";
import { cn } from "@/lib/utils";

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  interactive?: boolean;
  variant?: "surface" | "cream" | "gradient" | "tray";
}

export function Card({
  interactive = false,
  variant = "surface",
  className,
  children,
  ...props
}: CardProps) {
  const variantStyles = {
    surface:
      "bg-white/95 backdrop-blur-xs border border-brand-border/80 shadow-tactile hover:border-brand-gold/50",
    cream:
      "bg-gradient-to-b from-brand-cream to-brand-cream-warm border border-brand-border shadow-tactile",
    gradient:
      "bg-gradient-to-b from-white via-brand-cream to-brand-cream-warm border border-brand-gold/35 shadow-tactile",
    tray:
      "bg-brand-cream-warm/90 border-2 border-dashed border-brand-border shadow-inner",
  };

  return (
    <div
      className={cn(
        "rounded-2xl sm:rounded-3xl overflow-hidden transition-all duration-300",
        variantStyles[variant],
        interactive &&
          "cursor-pointer hover:-translate-y-1.5 hover:shadow-tactile-hover hover:border-brand-gold/60 active:translate-y-0 active:shadow-tactile",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}
