"use client";

import React from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "gold" | "outline" | "ghost" | "whatsapp";
  size?: "sm" | "md" | "lg";
  href?: string;
  isExternal?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export function Button({
  variant = "primary",
  size = "md",
  href,
  isExternal,
  leftIcon,
  rightIcon,
  className,
  children,
  ...props
}: ButtonProps) {
  const baseStyles =
    "inline-flex items-center justify-center font-medium rounded-full transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold focus-visible:ring-offset-2 active:scale-[0.98] active:translate-y-0.5 disabled:opacity-50 disabled:pointer-events-none select-none cursor-pointer";

  const sizeStyles = {
    sm: "text-xs px-4 py-2 min-h-[38px] gap-1.5",
    md: "text-sm px-5 py-2.5 min-h-[44px] gap-2 font-semibold",
    lg: "text-base px-7 py-3.5 min-h-[50px] gap-2.5 font-bold tracking-wide",
  };

  const variantStyles = {
    primary:
      "bg-gradient-to-b from-[#A31D33] via-[#8B1528] to-[#6E0F1E] text-white shadow-crimson-tactile hover:brightness-105 hover:-translate-y-0.5 border border-brand-crimson/30",
    secondary:
      "bg-gradient-to-b from-[#3B2218] via-[#2C1810] to-[#1E100A] text-white shadow-chocolate-tactile hover:brightness-110 hover:-translate-y-0.5 border border-brand-chocolate/40",
    gold:
      "bg-gradient-to-b from-[#ECC365] via-[#D8AA42] to-[#B78824] text-brand-chocolate shadow-gold-tactile hover:brightness-105 hover:-translate-y-0.5 border border-brand-gold/50 font-bold",
    outline:
      "border-2 border-brand-chocolate/20 text-brand-chocolate bg-white/70 hover:border-brand-chocolate hover:bg-white shadow-tactile-sm hover:shadow-tactile hover:-translate-y-0.5",
    ghost:
      "text-brand-chocolate hover:bg-brand-cream-warm/80 hover:text-brand-crimson",
    whatsapp:
      "bg-gradient-to-b from-[#3B2218] via-[#2A160F] to-[#1D0E09] text-brand-cream-warm shadow-chocolate-tactile hover:brightness-110 hover:-translate-y-0.5 border border-brand-gold/40 hover:border-brand-gold/70 font-semibold",
  };

  const combinedClasses = cn(
    baseStyles,
    sizeStyles[size],
    variantStyles[variant],
    className
  );

  const content = (
    <span className="inline-flex items-center gap-1.5 pointer-events-none">
      {leftIcon && <span className="inline-flex shrink-0">{leftIcon}</span>}
      <span>{children}</span>
      {rightIcon && <span className="inline-flex shrink-0">{rightIcon}</span>}
    </span>
  );

  if (href) {
    if (isExternal || href.startsWith("http") || href.startsWith("https://wa.me") || href.startsWith("tel:")) {
      return (
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className={combinedClasses}
        >
          {content}
        </a>
      );
    }

    return (
      <Link href={href} className={combinedClasses}>
        {content}
      </Link>
    );
  }

  return (
    <button
      type={props.type || "button"}
      className={combinedClasses}
      {...props}
    >
      {content}
    </button>
  );
}
