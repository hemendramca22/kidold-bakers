import React from "react";
import { cn } from "@/lib/utils";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: "crimson" | "gold" | "green" | "neutral" | "chocolate";
  children: React.ReactNode;
}

export function Badge({
  variant = "neutral",
  className,
  children,
  ...props
}: BadgeProps) {
  const variantStyles = {
    crimson: "bg-brand-crimson/10 text-brand-crimson border-brand-crimson/20",
    gold: "bg-brand-gold/15 text-brand-chocolate border-brand-gold/30 font-medium",
    green: "bg-emerald-50 text-emerald-800 border-emerald-200 font-medium",
    neutral: "bg-brand-cream-warm text-brand-chocolate/80 border-brand-border",
    chocolate: "bg-brand-chocolate text-white border-transparent",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs border tracking-wide select-none",
        variantStyles[variant],
        className
      )}
      {...props}
    >
      {children}
    </span>
  );
}

/**
 * Standard Indian FSSAI-style green dot badge for 100% Pure Veg / Eggless indicator
 */
export function VegIndicator({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center justify-center w-4 h-4 border-2 border-emerald-600 p-[2px] rounded-[3px] bg-white",
        className
      )}
      title="100% Pure Vegetarian / Eggless"
      aria-label="100% Pure Vegetarian"
    >
      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 block" />
    </span>
  );
}
