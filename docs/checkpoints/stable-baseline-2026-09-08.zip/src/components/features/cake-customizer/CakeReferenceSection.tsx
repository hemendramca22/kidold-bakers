﻿"use client";

import React, { useState, useRef, useEffect } from "react";
import { Badge } from "@/components/ui/Badge";
import { SparklesIcon } from "@/components/icons";

export interface CakeReferenceData {
  type: "upload" | "ai_concept";
  file?: File;
  previewUrl: string;
  fileName: string;
  fileSizeFormatted: string;
  aiPrompt?: string;
}

interface CakeReferenceSectionProps {
  referenceData: CakeReferenceData | null;
  onReferenceChange: (data: CakeReferenceData | null) => void;
}

const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB
const ALLOWED_MIME_TYPES = ["image/jpeg", "image/png", "image/webp"];

export function CakeReferenceSection({
  referenceData,
  onReferenceChange,
}: CakeReferenceSectionProps) {
  const [activeTab, setActiveTab] = useState<"upload" | "ai">("upload");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Cleanup object URL on unmount or replace
  useEffect(() => {
    return () => {
      if (referenceData?.previewUrl && referenceData.previewUrl.startsWith("blob:")) {
        URL.revokeObjectURL(referenceData.previewUrl);
      }
    };
  }, [referenceData?.previewUrl]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMsg(null);
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate mime type
    if (!ALLOWED_MIME_TYPES.includes(file.type)) {
      setErrorMsg("Please select a standard image format (JPEG, PNG, or WebP).");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }

    // Validate size
    if (file.size > MAX_FILE_SIZE_BYTES) {
      setErrorMsg("Image size exceeds 5MB limit. Please choose a smaller photo.");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }

    const previewUrl = URL.createObjectURL(file);
    const sizeInMb = (file.size / (1024 * 1024)).toFixed(2);

    onReferenceChange({
      type: "upload",
      file,
      previewUrl,
      fileName: file.name,
      fileSizeFormatted: `${sizeInMb} MB`,
    });
  };

  const handleRemove = () => {
    if (referenceData?.previewUrl && referenceData.previewUrl.startsWith("blob:")) {
      URL.revokeObjectURL(referenceData.previewUrl);
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
    setErrorMsg(null);
    onReferenceChange(null);
  };

  const handleTriggerUpload = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="space-y-4 pt-2">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-sm font-bold text-brand-chocolate uppercase tracking-wider">
            Add a Cake Reference (Optional)
          </h4>
          <p className="text-xs text-brand-chocolate/75 mt-0.5">
            Share an inspiration photo or design reference with our Jaunpur decorators.
          </p>
        </div>
      </div>

      {/* Choice Pills: Option A (Upload) vs Option B (AI - Coming Soon) */}
      <div className="flex items-center gap-2 border-b border-brand-border/60 pb-3">
        <button
          type="button"
          onClick={() => setActiveTab("upload")}
          className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${
            activeTab === "upload"
              ? "bg-brand-chocolate text-white shadow-tactile-sm"
              : "bg-white/80 text-brand-chocolate/70 hover:bg-white hover:text-brand-chocolate border border-brand-border/60"
          }`}
        >
          📷 Option A: Upload Reference
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("ai")}
          className={`px-4 py-2 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${
            activeTab === "ai"
              ? "bg-brand-gold/20 text-brand-chocolate border border-brand-gold/60 shadow-tactile-sm"
              : "bg-white/60 text-brand-chocolate/60 hover:bg-white/80 border border-brand-border/60"
          }`}
        >
          <SparklesIcon className="w-3.5 h-3.5 text-brand-gold" />
          <span>Option B: AI Concept</span>
          <span className="text-[10px] bg-brand-crimson/10 text-brand-crimson font-bold px-1.5 py-0.2 rounded-full">
            Coming Soon
          </span>
        </button>
      </div>

      {/* TAB A: UPLOAD FROM DEVICE */}
      {activeTab === "upload" && (
        <div className="rounded-2xl p-4 sm:p-5 bg-white/90 border border-brand-border/80 shadow-tactile-sm space-y-4">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={handleFileSelect}
            className="hidden"
            aria-label="Upload cake reference image"
          />

          {!referenceData ? (
            /* Empty State / Upload Dropzone Trigger */
            <div
              onClick={handleTriggerUpload}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  handleTriggerUpload();
                }
              }}
              role="button"
              tabIndex={0}
              className="border-2 border-dashed border-brand-gold/50 hover:border-brand-gold rounded-2xl p-6 text-center cursor-pointer transition-colors bg-brand-cream/40 hover:bg-brand-cream/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-gold"
            >
              <div className="w-12 h-12 rounded-full bg-brand-gold/20 text-brand-gold flex items-center justify-center mx-auto mb-3 shadow-tactile-sm">
                <svg
                  className="w-6 h-6 text-brand-chocolate"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </div>
              <p className="text-xs sm:text-sm font-bold text-brand-chocolate">
                Click to choose an inspiration photo from your device
              </p>
              <p className="text-[11px] text-brand-chocolate/65 mt-1">
                Supports JPEG, PNG, WebP up to 5MB
              </p>
            </div>
          ) : (
            /* Selected Image Preview State */
            <div className="flex flex-col sm:flex-row items-center gap-4 p-3 bg-brand-cream-warm/70 rounded-xl border border-brand-gold/40">
              <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-xl overflow-hidden border border-brand-border bg-white shrink-0 shadow-tactile-sm">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={referenceData.previewUrl}
                  alt="Customer Cake Reference Preview"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="flex-1 text-center sm:text-left space-y-1">
                <div className="flex items-center justify-center sm:justify-start gap-1.5">
                  <span className="text-xs font-bold text-brand-chocolate font-serif line-clamp-1">
                    {referenceData.fileName}
                  </span>
                  <Badge variant="gold" className="text-[9px] py-0 px-1.5">
                    {referenceData.fileSizeFormatted}
                  </Badge>
                </div>
                <p className="text-[11px] text-emerald-800 font-semibold flex items-center justify-center sm:justify-start gap-1">
                  <span>✓</span> Reference selected for WhatsApp brief
                </p>

                <div className="flex items-center justify-center sm:justify-start gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleTriggerUpload}
                    className="text-xs font-semibold px-3 py-1 rounded-lg bg-white border border-brand-border text-brand-chocolate hover:bg-brand-cream transition-colors shadow-2xs"
                  >
                    Change Image
                  </button>
                  <button
                    type="button"
                    onClick={handleRemove}
                    className="text-xs font-semibold px-3 py-1 rounded-lg bg-white border border-rose-200 text-rose-700 hover:bg-rose-50 transition-colors shadow-2xs"
                  >
                    Remove
                  </button>
                </div>
              </div>
            </div>
          )}

          {errorMsg && (
            <p className="text-xs text-rose-700 font-semibold bg-rose-50 border border-rose-200 px-3 py-1.5 rounded-lg">
              ⚠️ {errorMsg}
            </p>
          )}

          {/* Privacy & WhatsApp Attachment Guidance Note */}
          <div className="space-y-1 text-[11px] text-brand-chocolate/75 border-t border-brand-border/40 pt-3">
            <p className="flex items-start gap-1.5">
              <span className="text-brand-gold shrink-0">🔒</span>
              <span>
                <strong>Privacy Protected:</strong> We do not permanently store your photos. Your preview stays local in your browser.
              </span>
            </p>
            <p className="flex items-start gap-1.5">
              <span className="text-brand-crimson shrink-0">💬</span>
              <span>
                <strong>WhatsApp Ordering:</strong> Your cake preferences will be prepared for WhatsApp. You can attach this reference image directly in WhatsApp before sending.
              </span>
            </p>
          </div>
        </div>
      )}

      {/* TAB B: AI CONCEPT GENERATOR (COMING SOON BOUNDARY) */}
      {activeTab === "ai" && (
        <div className="rounded-2xl p-5 sm:p-6 bg-white/80 border border-brand-gold/40 shadow-tactile-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-brand-gold/20 text-brand-gold flex items-center justify-center shadow-2xs">
                <SparklesIcon className="w-4 h-4 text-brand-gold" />
              </div>
              <h5 className="font-bold text-sm text-brand-chocolate font-serif">
                Generate My Cake Concept with AI
              </h5>
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider bg-brand-crimson/10 text-brand-crimson px-2.5 py-1 rounded-full border border-brand-crimson/20">
              Coming Soon
            </span>
          </div>

          <p className="text-xs text-brand-chocolate/80 leading-relaxed">
            Describe your celebration idea and we&apos;ll generate an artisan visual cake concept before you order.
          </p>

          <div className="space-y-2">
            <label
              htmlFor="ai-concept-prompt"
              className="text-[11px] font-bold text-brand-chocolate/70 block"
            >
              Dream Cake Description:
            </label>
            <textarea
              id="ai-concept-prompt"
              disabled
              rows={2}
              placeholder='e.g., "Two-tier pastel peach and gold vintage cake with delicate piped roses and golden pearl beads"'
              className="w-full px-3.5 py-2.5 rounded-xl bg-brand-cream/50 border border-brand-border text-xs text-brand-chocolate/60 placeholder:text-brand-chocolate/40 cursor-not-allowed resize-none opacity-80"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-[11px] text-brand-chocolate/60 italic">
              AI generation pipeline will be activated in an upcoming release.
            </span>
            <button
              type="button"
              disabled
              className="px-4 py-2 rounded-full text-xs font-bold bg-brand-chocolate/20 text-brand-chocolate/50 cursor-not-allowed"
            >
              Generate Preview (Coming Soon)
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
