import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

let isRegistered = false;

/**
 * Registers GSAP plugins safely on client-side only.
 */
export function registerGSAP() {
  if (typeof window !== "undefined" && !isRegistered) {
    gsap.registerPlugin(ScrollTrigger);
    isRegistered = true;
  }
  return { gsap, ScrollTrigger };
}

/**
 * Checks if the user prefers reduced motion.
 */
export function shouldReduceMotion(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

/**
 * Animates a section heading with a cinematic masked/staggered reveal:
 * - badge fades and scales gently
 * - title translates up smoothly
 * - subtitle follows
 * - accent line expands smoothly from center (scaleX 0 -> 1)
 */
export function animateHeadingReveal(
  container: HTMLElement,
  trigger?: HTMLElement | null
) {
  if (typeof window === "undefined" || shouldReduceMotion()) return null;

  const { gsap } = registerGSAP();
  const triggerTarget = trigger || container;

  const tl = gsap.timeline({
    scrollTrigger: {
      trigger: triggerTarget,
      start: "top 85%",
      toggleActions: "play none none none",
    },
  });

  const badge = container.querySelector('[class*="bg-brand-crimson/10"]');
  const title = container.querySelector("h2");
  const subtitle = container.querySelector("p");
  const divider = container.querySelector('[class*="bg-gradient-to-r from-brand-gold"]');

  if (badge) {
    tl.fromTo(
      badge,
      { opacity: 0, y: 14, scale: 0.96 },
      { opacity: 1, y: 0, scale: 1, duration: 0.5, ease: "power2.out" }
    );
  }

  if (title) {
    tl.fromTo(
      title,
      { opacity: 0, y: 22 },
      { opacity: 1, y: 0, duration: 0.65, ease: "power2.out" },
      badge ? "-=0.35" : 0
    );
  }

  if (subtitle) {
    tl.fromTo(
      subtitle,
      { opacity: 0, y: 16 },
      { opacity: 1, y: 0, duration: 0.55, ease: "power2.out" },
      "-=0.4"
    );
  }

  if (divider) {
    tl.fromTo(
      divider,
      { scaleX: 0, opacity: 0, transformOrigin: "center" },
      { scaleX: 1, opacity: 1, duration: 0.6, ease: "power2.out" },
      "-=0.3"
    );
  }

  return tl;
}

/**
 * Desktop-only scroll parallax layer. Inactive on mobile/reduced-motion.
 */
export function animateScrollParallax(
  element: HTMLElement | null,
  yPercent: number,
  trigger: HTMLElement | null,
  scrub: number | boolean = 0.6
) {
  if (
    typeof window === "undefined" ||
    shouldReduceMotion() ||
    window.innerWidth < 768 ||
    !element ||
    !trigger
  ) {
    return null;
  }

  const { gsap } = registerGSAP();
  return gsap.fromTo(
    element,
    { yPercent: -yPercent / 2 },
    {
      yPercent: yPercent / 2,
      ease: "none",
      scrollTrigger: {
        trigger,
        start: "top bottom",
        end: "bottom top",
        scrub,
      },
    }
  );
}

export { gsap, ScrollTrigger };
