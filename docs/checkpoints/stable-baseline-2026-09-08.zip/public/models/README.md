# 3D Asset Pipeline: Hero Cake Model

## Asset Specification
- **Target Filename**: `public/models/hero-cake.glb`
- **Format**: Binary glTF (`.glb`)
- **Target Size**: Under 3.0 MB (recommended 1.2 MB – 2.5 MB)
- **Compression**: Draco mesh compression + KTX2 / Basis Universal textures (optional, recommended)
- **Workflow**: Standard PBR Metallic-Roughness

## Model Structure Requirements
When exporting the final celebration cake asset from Blender / Cinema 4D / Maya, organize nodes with the following named hierarchy so the exploded-view and material controllers bind automatically:

```
HeroCakeRoot
├── Pedestal_Base (Ceramic turntable platter & foot)
├── Tier_Bottom
│   ├── Sponge_Bottom (Belgian cocoa crumb geometry)
│   ├── Frosting_Bottom (Champagne vanilla cream)
│   └── Ganache_Drips_Bottom (Chocolate drip apron)
├── Tier_Top
│   ├── Sponge_Top (Vanilla chiffon crumb geometry)
│   ├── Frosting_Top (Whipped cream coat)
│   └── Ganache_Crown_Top (Top drip ring)
└── Topper_Decorations
    ├── Berries_Raspberry
    ├── Berries_Blueberry
    ├── Gold_Leaf_Flakes
    └── Plaque_Celebration
```

## How the Application Loads this Asset
1. Place `hero-cake.glb` directly in this directory (`public/models/hero-cake.glb`).
2. [`HeroCakeMesh.tsx`](../../src/components/sections/hero/HeroCakeMesh.tsx) uses `@react-three/drei`'s `useGLTF`.
3. The component checks for model presence; as soon as the real GLB is dropped into this folder, it seamlessly replaces the procedural placeholder with zero code changes.
