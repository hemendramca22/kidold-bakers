/** @type {import('next').NextConfig} */
const nextConfig = {
  // Keep development HMR artifacts separate from production build artifacts.
  // This prevents `next build` and `next dev` from invalidating each other's chunks.
  distDir: process.env.NODE_ENV === "development" ? ".next-dev" : ".next",
  // Prevent aggressive disposal of chunks when tab is left idle in development
  onDemandEntries: {
    maxInactiveAge: 60 * 1000 * 60, // Keep in memory for 1 hour
    pagesBufferLength: 20,
  },
  images: {
    formats: ["image/avif", "image/webp"],
    remotePatterns: [
      {
        protocol: "https",
        hostname: "images.unsplash.com",
      },
    ],
  },
};

export default nextConfig;
